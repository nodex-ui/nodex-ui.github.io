# Scaffold a NodexUI PWA (`create app` / `create application`)

The canonical example of this scaffold in the wild is `qr-page/` at the repo root — open it and
copy its shape, don't reinvent one. It is a real, shipped, installable PWA built entirely on
NodexUI's pure Nodex UI API. Everything below documents *why* that folder is shaped the way it is, so you
can adapt it to a new app name/domain rather than copy placeholder text.

## File layout to produce

For an app named `<app>` (kebab-case, e.g. `todo-app`), create a sibling top-level folder:

```
<app>/
  index.html              # entry HTML: meta tags, importmap, mounts #app, loads <app>.js
  <app>.js                 # Nodex root component + mount() + service worker registration
  <app>.xml                # Nodex templates for the root component (and any small sub-components)
  <app>.css                # app-specific styles layered on top of nodexui.min.css
  manifest.webmanifest      # PWA manifest (name, icons, start_url, display: standalone)
  sw.js                     # service worker: precache app shell, network-first fetch, version.json check
  version.json              # {"version":"<hash>"} polled by sw.js; change it every deploy
  favicon.svg
  icons/
    icon-192.png
    icon-512.png
  robots.txt
  sitemap.xml
  vendor/                   # only if the app needs a third-party JS lib with no npm/CDN story
                             # NodexUI itself is never vendored here — it's CDN or /dist
```

Only add `vendor/` if there's a genuine third-party dependency (like `qr-page`'s QR-encoding lib).
Don't create it empty.

## index.html

Load NodexUI once, via CDN (default) or `/dist/*` (if the app is served from within the NodexUI source repo's own
build output — see `docs/installation.md` for both paths). Always pin a version on the CDN URLs;
never use `@latest` outside of a throwaway demo.

```html
<!doctype html>
<html lang="en" b-theme="light">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><App Name></title>
    <meta name="description" content="<one or two sentences of what the app does>" />
    <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
    <link rel="manifest" href="/manifest.webmanifest" />
    <meta name="theme-color" content="#0f172a" />

    <script type="importmap">
      {
        "imports": {
          "nodexui": "https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/nodexui.esm.js",
          "nodexui/templates": "https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/nodexui.templates.xml"
          /* optional: "nodexui/icons" → dist/nodexui.icons.esm.js (named <IconEye/> exports),
             "nodexui/analytics" → dist/nodexui.analytics.esm.js (see "Optional add-ons" below) */
        }
      }
    </script>
    <!-- Everything below the import map: preload hints and stylesheets. The import map must stay FIRST
         (before any modulepreload or module script) or the browser ignores it. -->
    <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin />
    <link rel="modulepreload" href="https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/nodexui.esm.js" crossorigin />
    <link rel="preload" as="fetch" crossorigin href="https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/nodexui.templates.xml" />
    <link rel="modulepreload" href="/<app>.js" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/nodexui.min.css" />
    <link rel="stylesheet" href="/<app>.css" />
  </head>
  <body class="bg-body text-body">
    <div id="app"></div>
    <noscript>
      <!-- Plain-text fallback describing the app, for crawlers and JS-disabled visitors -->
    </noscript>
    <script type="module" src="/<app>.js"></script>
  </body>
</html>
```

`<version>` above is a placeholder — use the version resolved by `SKILL.md`'s "Pin the `nodexui`
version once" section before hardcoding the CDN version segment; don't assume it's
still current.

Comments inside the JSON above are illustrative — strip them in the real file.

Why this order: a `<link rel="modulepreload">` or module script that appears before the import map makes the browser ignore the map (unresolved `nodexui`), and the preload/`preconnect` lines let the CDN module and the templates XML download in parallel with your own code instead of being discovered late. Once the app grows past one screen, read `load-performance.md` (flat preload lists, lazy views, cold-load measuring) before adding more `<link>` lines by hand.

## Two scaffold paths: static importmap (this doc) vs. the CLI's Vite project

- **Static importmap PWA** (the `qr-page/` shape, documented below): no build step, NodexUI from CDN.
  Default for `create app` unless the user asks for npm/Vite.
- **Vite + npm project** via the shipped CLI (`bin/create-nodexui-app.mjs`; from a consumer project
  `npx -p nodexui create-nodexui-app ...`; the bin ships inside `nodexui`, so a bare `npx create-nodexui-app` returns 404 unless `nodexui` is already installed in that project). Imports come from `nodexui` directly (no importmap) and templates
  are loaded with `?raw`:
  - `create <name>` — minimal Vite + NodexUI counter app (`src/main.js`, `src/App.js`, `src/App.xml`).
  - `init <name>` — 4-page starter: landing, login, signup, authenticated home shell (sidebar +
    header), ported from the `login-03` / `signup-03` / `sidebar-02` blocks. Prefer this when the user
    wants login/landing/dashboard pages.
  - `convert [path]` — turn an existing folder into a Vite + NodexUI project, never overwriting files.
  - `pwa [path] --config nodexui.pwa.config.js` — generate `manifest.webmanifest`, `sw.js` and default
    icons (see "manifest.webmanifest and sw.js" below).
  - `docs [folder] [--restructure [--write]] [--check]` — prepare a Markdown folder for the `DocViewer`
    component (root `index.md`, per-folder `readme.md`, `tree.json`); see `docs/components/doc-viewer.md`.
  Flags: `--version <x.y.z>`, `--no-install`, `--force`. Run the CLI rather than hand-writing these
  files; read `bin/create-nodexui-app.mjs` for the exact output when adapting.

## `<app>.js` — the Nodex root

```js
import { Component, mount, useState } from "nodexui";
import { Button, Card, CardBody /* ...whatever components this app needs */ } from "nodexui";

/** Registers the offline service worker and reloads the page when a new app version is deployed (see "Auto-reload on a new version"). */
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.addEventListener("message", (event) => {
    if (event.data === "version-changed") location.reload();
  });
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) navigator.serviceWorker.controller?.postMessage("check-version");
  });
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch((error) => {
      console.error("Service worker registration failed", error);
    });
  });
}

/** Root screen of the app: owns the top-level state and composes the NodexUI components below. */
class Root extends Component {
  static template = "app.Root";
  static components = { Button, Card, CardBody };

  setup() {
    this.state = useState({ /* whatever this app's UI needs to react to */ });
  }
}

/** Both files are full <templates>...</templates> documents — strip each one's outer wrapper
 * before joining them, otherwise the merged string has two root elements and Nodex's XML parser
 * throws (a real gotcha: it surfaces as a confusing "RangeError: Invalid count value: -1", not an
 * XML parse error, due to a bug in Nodex's own error-formatting code). */
const stripTemplatesWrapper = (xml) => xml.replace(/^\s*<templates[^>]*>/, "").replace(/<\/templates>\s*$/, "");

const [nodexuiTemplates, appTemplates] = await Promise.all([
  fetch(import.meta.resolve("nodexui/templates")).then((r) => r.text()),
  fetch(new URL("./<app>.xml", import.meta.url)).then((r) => r.text()),
]);
const templates = `<templates>${stripTemplatesWrapper(nodexuiTemplates)}${stripTemplatesWrapper(appTemplates)}</templates>`;
await mount(Root, document.getElementById("app"), { templates });
```

This is exactly the pattern `qr-page/qr-page.js` uses — copy it verbatim rather than naively
concatenating the two fetched strings.

Follow `docs/owl-components.md` for the exact template-loading contract — a component class alone
does not carry its template; `nodexui/templates` (NodexUI's own components) and the app's own
`<app>.xml` both need to be fetched and merged before `mount()`.

## `<app>.xml`

One Nodex template per screen/section, namespaced under the app's own name (not `nodexui.*`, that
namespace belongs to NodexUI itself):

```xml
<templates xml:space="preserve">
  <t t-name="app.Root">
    <div class="container py-4">
      <Card>
        <CardBody>
          <!-- actual UI here, using NodexUI component tags -->
        </CardBody>
      </Card>
    </div>
  </t>
</templates>
```

## manifest.webmanifest and sw.js — prefer generating them

Don't hand-write these two files from the templates below if `nodexui/pwa` is available at the
pinned version (check `node_modules/nodexui/package.json`'s `exports["./pwa"]`, or the CDN's
`nodexui.pwa.esm.js`; it exists from 1.1.x on, so in the NodexUI source repo it always does). The CLI imports
`dist/nodexui.pwa.esm.js`, so run `npm run build` first when working in the NodexUI source repo. Write a `nodexui.pwa.config.js` with the app's `manifest`/`serviceWorker`
config instead (real example: `examples/nodexui.pwa.config.js`), then run
`npx -p nodexui create-nodexui-app pwa . --config nodexui.pwa.config.js` (in the NodexUI source repo:
`node bin/create-nodexui-app.mjs pwa <app> --config <file>`) to generate both files plus the default
logo/favicon set in `icons/` (`favicon.ico`, 16/32 px favicons, `apple-touch-icon.png`, `icon-192.png`, `icon-512.png`; existing files are never overwritten, so your own icons win). The default manifest icons and precache list point at this set; if icons live in another folder set `iconsBase` (manifest + service worker) and `manifestUrl` (service worker) in the config. Required config: `manifest.name`,
`serviceWorker.cacheName`, `serviceWorker.cdnVersion` (must equal the importmap pin);
`serviceWorker.appFiles` lists the app shell. Re-run after any change — outputs are fully regenerated. See
`docs/usage-guide.md` §"PWA toolkit (optional)" for the config shape. Only fall back to hand-writing
the templates below if the pinned version predates that export.

```json
{
  "name": "<Full App Name>",
  "short_name": "<Short Name>",
  "description": "<one sentence>",
  "start_url": "/",
  "scope": "/",
  "display": "standalone",
  "orientation": "portrait-primary",
  "background_color": "#ffffff",
  "theme_color": "#0f172a",
  "lang": "en",
  "icons": [
    { "src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
    { "src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any" },
    { "src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ]
}
```

## sw.js — network-first, app-shell precached

Precache the app shell (HTML/CSS/JS/manifest/icons) on install, then prefer network responses at
runtime and fall back to cache only when offline — this way a returning user always gets the latest
deploy while still getting a working app with no connection.

```js
const CACHE_NAME = "<app>-cache-v1";

const PRECACHE_URLS = [
  "/", "/manifest.webmanifest", "/<app>.css", "/<app>.js", "/<app>.xml",
  "/favicon.svg", "/icons/icon-192.png", "/icons/icon-512.png",
  "https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/nodexui.min.css",
  "https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/nodexui.esm.js",
  "https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/nodexui.templates.xml",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE_URLS)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

/** Always tries the network first so users get fresh content; falls back to the cached copy only when offline. */
self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  event.respondWith(
    caches.open(CACHE_NAME).then(async (cache) => {
      try {
        const response = await fetch(request, { cache: "no-cache" });
        if (response.ok) cache.put(request, response.clone());
        return response;
      } catch {
        const cached = await cache.match(request);
        if (cached) return cached;
        throw new Error(`No cached response for ${request.url} and network unavailable`);
      }
    })
  );
});
```

Same-origin-only fetch handling (see `qr-page/sw.js`) is optional — add the origin check back in if
the app also talks to a same-origin API you don't want the SW caching by accident.

Hand-written `sw.js` reference: `qr-page/sw.js` — network-first for same-origin, plus a cache-first
branch for the pinned NodexUI CDN prefix (a published version never changes, so offline works after the
first visit). Bump `CACHE_NAME` whenever the precache list changes.

## Auto-reload on a new version — `version.json`

Every PWA this skill builds must reload its open pages when a new version is deployed. Contract:

- `version.json` at the app root: `{"version":"<value>"}`, never cached (the SW fetches it with `cache: "no-store"` and skips it in the fetch handler). The value must change on every release — a content hash of the shipped files, not a hand-edited number.
- `sw.js` runs one check (shared in-flight promise) on `activate`, on every `navigate` fetch, and on a page `postMessage("check-version")`. It keeps the last-seen value in a separate `<cacheName>-version` cache so wiping the app caches never forgets it. First sight only records; a change wipes all other caches, re-precaches with `cache: "reload"`, then posts `"version-changed"` to every window client. Network/server failure is swallowed (retry on the next trigger).
- The page (`<app>.js` or `sw-register.js`) reloads on `"version-changed"` and posts `"check-version"` on `visibilitychange` when visible.
- **Default for Vite projects**: `create`/`init` scaffolds put `plugins: [nodexuiPwa({ name })]` (`import { nodexuiPwa } from "nodexui/vite"`) in `vite.config.js`; every `vite build` emits `manifest.webmanifest`, `sw.js`, `sw-register.js`, `version.json` (bundle hash) and default icons into `dist/` and injects the manifest/register tags into each page. Nothing else to run at deploy. For `convert`/existing projects add the plugin by hand; never remove it unless the user opts out of PWA.
- Static/no-bundler path: `npx -p nodexui create-nodexui-app pwa . --config nodexui.pwa.config.js` writes `sw.js` (with the logic), `sw-register.js` (load as `<script type="module" src="/sw-register.js">` instead of hand-registering) and `version.json` (hash of `sw.js`, manifest and every `appFiles` entry under the folder). **Re-run it as the last step of every deploy**, or have the deploy script write `version.json` itself from a content hash of the staged files (as the NodexUI repo's `deploy.sh` / `deploy_landing.sh` do). A hand-written SW copies the logic from `qr-page/sw.js`.
- Apps without a deploy pipeline (e.g. `momo_demo/`): bump `version.json` by hand on each release.
- Use scope-relative `new URL("version.json", self.registration.scope)` so sub-path deployments work.

## Optional add-ons (only when the app needs them)

- **Pinned icon CDN**: `qr-page.js` sets `window.thebase.icons.lucide.cdnBaseUrl` to
  `https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/icons/lucide` so icons match the pin
  instead of the lucide-static default.
- **Analytics**: add `"nodexui/analytics"` to the importmap, then lazily
  `import("nodexui/analytics").then((m) => m.init({ backendUrl, outboundLinks: true, fileDownloads: true,
  customProperties: m.visitorContext }))` and `m.track(name, { props })` (pattern in `qr-page.js`; options and
  backend contract in `docs/analytics.md`). Never put user-typed content in event props.
- **SEO/PWA head tags** `qr-page/index.html` also carries: `apple-touch-icon`, `apple-mobile-web-app-*`
  metas, canonical/hreflang, Open Graph/Twitter cards, JSON-LD, plus `robots.txt`/`sitemap.xml`. Include
  these only for public-facing apps.
- **Deploy**: `qr-page/` ships via `deploy.sh` (which stamps `version.json` with a content hash); it needs a root-absolute path layout (`/sw.js`,
  `/manifest.webmanifest`), so serve the app at the domain root.

## Offline data and realtime, if the app needs them

- **Local persistence**: `localStorage` for small flags/preferences (see `qr-page`'s
  `NOTIFY_DISMISSED_KEY` pattern); IndexedDB (directly, or via a tiny wrapper) for structured
  records; PouchDB when the app needs sync/replication against a CouchDB-compatible backend, not
  just local storage.
- **Realtime**: a plain `WebSocket` for a single backend-owned channel; MQTT (e.g. `mqtt.js` over
  WebSocket) when the app needs pub/sub across many topics or is joining an existing MQTT bus (this
  repo's Go backend skill uses EMQX — check with the user which broker the app talks to).
Only add these when the app actually needs them — don't scaffold empty abstractions for
hypothetical offline/realtime features.

## Verification

Serve the folder (e.g. `npx serve <app>` or any static server) and load it once. Confirm: no
console errors, the importmap resolves, the root component renders, and the manifest/service worker
register without errors in DevTools → Application. Kill the dev server before ending the task. For a load-time
check, use `scripts/measure-cold-load.mjs` (service worker blocked): a warm service worker hides first-visit cost.
