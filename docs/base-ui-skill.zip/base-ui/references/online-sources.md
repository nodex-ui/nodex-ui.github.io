# Online NodexUI sources (search these after the local tiers)

The live NodexUI site, `https://ui.thebase.vn`, publishes the same docs, block demos, icon list and
Nodex documentation that the source repo holds. Use it **after** the local tiers (this skill's
`references/`, then the repo's `docs/`/`src/`/`dist/` or the installed `node_modules/nodexui`)
and **before** generic web search. It matters most for consumer projects that have no local copy of
`docs/` or `examples/`.

## Why the browser URLs are not what you fetch

The four pages people share are hash-routed views of one single-page app:

| Page (browser) | What it is |
| --- | --- |
| `https://ui.thebase.vn/examples/index.html#/docs` | component + guide documentation |
| `https://ui.thebase.vn/examples/index.html#/blocks` | block gallery |
| `https://ui.thebase.vn/examples/index.html#/icons` | icon gallery |
| `https://ui.thebase.vn/examples/index.html#/concept` | Nodex runtime docs (`docs/v2`) |

Fetching one of them returns only the app shell (the part after `#` never reaches the server). Each
view renders plain files, so fetch those files directly. All paths below were checked against the
live site and return the raw content.

| Need | Raw file to fetch (prefix `https://ui.thebase.vn`) | Browser route it backs |
| --- | --- | --- |
| A component's props, slots, events, examples | `/docs/components/<name>.md` (e.g. `button.md`, `card.md`, `shell.md`) | `#/docs/components/<name>` |
| A guide (install, mounting, theming, runtime API) | `/docs/<slug>.md`, slug one of `usage-guide`, `installation`, `theming`, `runtime-api`, `analytics`, `registry`, `owl-components`, `blocks`, `icons`, `base-ui-skill` | `#/docs/guide/<slug>` |
| Exact component names, props, events | `/dist/nodexui.registry.json` | n/a |
| Real template of a component | `/dist/nodexui.templates.xml` | n/a |
| A block's markup (copy-ready) | `/examples/components/block-gallery/blocks/<name>.xml` | `#/blocks` |
| A hero/features/CTA/footer landing page built with NodexUI | `/examples/components/landing/landing.xml` + `landing.css` | site root |
| Full icon name list | `/dist/icons/lucide.json` (`icons` array) | `#/icons` |
| Nodex docs index, then a page | `/docs/v2/tree.json`, then `/` + the `path` it lists (e.g. `/docs/v2/reference/app.md`, `/docs/v2/readme.md`) | `#/concept/<path>` |

Fetch with whatever the session offers (`WebFetch`, or `curl -sL`). If a fetch fails or returns the
HTML shell instead of the file, say so in the report and continue with the local tiers; never
reconstruct the missing content from memory.

## What blocks really are

The block gallery holds **page-level compositions**, not marketing sections:

- `sidebar-01` … `sidebar-16` (app and docs navigation shells), `dashboard-01`, `data-table-01`,
  `chart-01`, `apidoc-01`, `login-03`/`login-04`, `signup-03`/`signup-04`.
- `<component>-demo` pages: one realistic, copy-ready usage of each component (`card-demo`,
  `tabs-demo`, `field-demo`, …).

There is no hero, pricing or footer block. For those sections compose `page-layouts.md` recipes from
components and use `landing.xml` above as the reference. Block files such as `login-03.html` carry their
source as a pure Nodex UI Nodex template inside `<script type="text/xml" b-block-code-template>`: copy that
template into your `site.xml` (rename its `t-name`, swap in the user's content) and import the
components it uses. Some blocks are written as static `b-block`/`b-ui` markup (see `docs/blocks.md`);
translate those to pure Nodex UI per `syntax.md` rather than shipping static markup, unless the user asked
for static HTML.

## Rules for using what you fetch

1. **Version drift.** The live site tracks the newest release, which may be ahead of the version you
   pinned. Treat fetched markup as a lead and confirm every component, prop and event name against
   the pinned version's `nodexui.registry.json` (`https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/nodexui.registry.json`)
   before writing it. Mention any mismatch in the report.
2. **Smallest fetch that answers the question.** Pull the one component doc or one block, not the whole
   gallery; large pages cost context and rarely help.
3. **Adapt, don't paste.** Swap the demo content for the user's. Blocks that use `b-block` markup also
   need their own CSS (`examples/components/block-gallery/blocks/<name>.css`, shared `shared.css`); pure Nodex UI templates such as
   `login-03` need only `nodexui.min.css`. In the report, list the exact raw URL or path of every block
   or doc you used.
