#!/usr/bin/env node
/**
 * Scaffold a pure Nodex UI + static-adapter component file set.
 *
 * Generates the four-file pure Nodex UI + static-adapter authoring contract
 * (the NodexUI component-authoring convention):
 *
 *   <dir>/<slug>/<slug>.component.js   pure Nodex UI component class(es)
 *   <dir>/<slug>/<slug>.xml            Owl template(s)
 *   <dir>/<slug>/<slug>.js             static adapter (marker/registry mount)
 *   <dir>/<slug>/<slug>.css            shared styles for both APIs
 *   <dir>/<slug>/<slug>.behavior.js    optional, only with --behavior
 *
 * This script is project-agnostic on purpose (copy it into any Owl-based
 * repo's scripts/ folder, or run it straight from this skill folder with
 * --dir pointed at the target repo). It does not assume a specific registry
 * API — the static adapter file is emitted with a TODO wiring block plus
 * --registry-import/--registry-global flags so you can point it at whatever
 * NodexUI.register(...)-style call the target project actually uses.
 *
 * Usage:
 *   node new-owl-component.mjs <slug> [options]
 *
 * Options:
 *   --dir <path>              Components root (default: src/components)
 *   --namespace <name>        Owl template namespace prefix (default: nodexui)
 *   --facade <name>           Owl import specifier for the component class
 *                             file (default: nodexui)
 *   --registry-global <name>  Global registry object name (default: NodexUI)
 *   --registry-import <path>  Import path for the registry, relative to the
 *                             generated <slug>.js (default:
 *                             ../../runtime/nodexui.js)
 *   --behavior                Also emit <slug>.behavior.js
 *   --no-css                  Skip the .css file
 *   --register                Append `export { ClassName } from "./slug/
 *                             slug.component.js";` to <dir>/index.js
 *                             (created if missing) instead of leaving that
 *                             step as a manual TODO
 *   --force                   Overwrite existing files instead of skipping
 *
 * Example:
 *   node new-owl-component.mjs tooltip --dir src/components --register
 *   node new-owl-component.mjs data-table --namespace myui --behavior
 */

import { mkdirSync, writeFileSync, existsSync, readFileSync, appendFileSync } from "node:fs";
import { join } from "node:path";

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--behavior") args.behavior = true;
    else if (a === "--no-css") args.noCss = true;
    else if (a === "--force") args.force = true;
    else if (a === "--register") args.register = true;
    else if (a === "--dir") args.dir = argv[++i];
    else if (a === "--namespace") args.namespace = argv[++i];
    else if (a === "--facade") args.facade = argv[++i];
    else if (a === "--registry-global") args.registryGlobal = argv[++i];
    else if (a === "--registry-import") args.registryImport = argv[++i];
    else args._.push(a);
  }
  return args;
}

function registerExport(dir, slug, className) {
  const indexPath = join(dir, "index.js");
  const exportLine = `export { ${className} } from "./${slug}/${slug}.component.js";`;
  if (!existsSync(indexPath)) {
    writeFileSync(
      indexPath,
      `// Aggregate export of every pure Nodex UI component class.\n${exportLine}\n`,
      "utf8"
    );
    console.log(`wrote: ${indexPath} (created)`);
    return;
  }
  const contents = readFileSync(indexPath, "utf8");
  if (contents.includes(exportLine)) {
    console.log(`skip (already registered): ${indexPath}`);
    return;
  }
  appendFileSync(indexPath, `${exportLine}\n`, "utf8");
  console.log(`updated: ${indexPath} (appended export)`);
}

function toPascalCase(slug) {
  return slug
    .split(/[-_]/g)
    .filter(Boolean)
    .map((part) => part[0].toUpperCase() + part.slice(1))
    .join("");
}

function writeIfAllowed(path, content, force) {
  if (existsSync(path) && !force) {
    console.log(`skip (exists): ${path}`);
    return;
  }
  writeFileSync(path, content, "utf8");
  console.log(`wrote: ${path}`);
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const slug = args._[0];
  if (!slug) {
    console.error("Usage: node new-owl-component.mjs <slug> [options]");
    process.exit(1);
  }
  if (!/^[a-z][a-z0-9]*(-[a-z0-9]+)*$/.test(slug)) {
    console.error(
      `Invalid slug "${slug}" — use kebab-case, e.g. "button" or "data-table".`
    );
    process.exit(1);
  }

  const dir = args.dir || "src/components";
  const namespace = args.namespace || "nodexui";
  const facade = args.facade || "nodexui";
  const registryGlobal = args.registryGlobal || "NodexUI";
  const registryImport = args.registryImport || "../../runtime/nodexui.js";
  const className = toPascalCase(slug);
  const componentDir = join(dir, slug);

  mkdirSync(componentDir, { recursive: true });

  const componentJs = `import { Component } from "${facade}";

export class ${className} extends Component {
  static template = "${namespace}.${className}";
  static props = {
    className: { type: String, optional: true },
    slots: { type: Object, optional: true },
  };
}
`;

  const xml = `<templates xml:space="preserve">
  <t t-name="${namespace}.${className}">
    <div t-attf-class="${namespace}-${slug} {{props.className}}">
      <t t-slot="default"/>
    </div>
  </t>
</templates>
`;

  const staticJs = `import { ${registryGlobal} } from "${registryImport}";
// TODO: confirm this import path/registry API matches the target project —
// this scaffold assumes a NodexUI.register(slug, { type, mount }) style API.
// Adjust to whatever registry pattern this repo actually uses.

function mount${className}(el) {
  el.classList.add("${namespace}-${slug}");
  // TODO: wire up DOM behavior shared with ${className.toLowerCase()}.behavior.js
  // if this component has interactive state (open/close, selection, etc.).
}

${registryGlobal}.register("${slug}", {
  type: "static",
  mount: mount${className},
});
`;

  const css = `[b-ui="${slug}"],
.${namespace}-${slug} {
  /* TODO: shared styles consumed by both the static adapter and the pure
     Owl template above. Prefer --${namespace}-* tokens over hardcoded values. */
}
`;

  const behaviorJs = `/**
 * Framework-agnostic behavior shared by ${slug}.js (static adapter) and
 * ${slug}.component.js (pure Nodex UI). Keep DOM/state logic here so both APIs
 * stay visually and behaviorally identical instead of drifting apart.
 */

export function create${className}Behavior(/* options */) {
  // TODO: return the shared open/close/select/etc. primitives this
  // component needs, consumed by both the static mount() and the Owl
  // component's setup().
  return {};
}
`;

  writeIfAllowed(join(componentDir, `${slug}.component.js`), componentJs, args.force);
  writeIfAllowed(join(componentDir, `${slug}.xml`), xml, args.force);
  writeIfAllowed(join(componentDir, `${slug}.js`), staticJs, args.force);
  if (!args.noCss) {
    writeIfAllowed(join(componentDir, `${slug}.css`), css, args.force);
  }
  if (args.behavior) {
    writeIfAllowed(join(componentDir, `${slug}.behavior.js`), behaviorJs, args.force);
  }
  if (args.register) {
    registerExport(dir, slug, className);
  }

  console.log(`\nNext steps:`);
  console.log(`  1. Fill in real props/slots/markup in ${slug}.component.js and ${slug}.xml.`);
  console.log(`  2. Fix the registry import/API in ${slug}.js for this project.`);
  if (!args.register) {
    console.log(`  3. Export ${className} from the components aggregator (e.g. ${dir}/index.js) — or rerun with --register.`);
  }
  console.log(`  ${args.register ? "3" : "4"}. Add ${slug} to the build's XML concatenation / registry metadata if this project has one.`);
  console.log(`  ${args.register ? "4" : "5"}. Scaffold a test with new-owl-test.mjs, or add tests manually for both the static and pure Nodex UI usage.`);
}

main();
