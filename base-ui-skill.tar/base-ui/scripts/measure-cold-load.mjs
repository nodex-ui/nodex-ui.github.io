#!/usr/bin/env node
// Measures a cold page load under throttling: first paint, time until a "content visible" selector
// appears, the slowest requests, and the main-thread CPU hot spots. The service worker is blocked and
// the HTTP cache disabled, because a warm worker hides what a first-time visitor pays.
//
// Usage: node measure-cold-load.mjs --url http://localhost:8080/web --selector "table tbody tr"
//        [--bw 1600] [--rtt 100] [--cpu 4] [--session-storage '{"app-auth":"{...json...}"}']
//        [--chromium /path/to/chrome]   (or env CHROMIUM_PATH) when Playwright's own browser build is not installed
// Needs: npm i playwright-core, and an installed Chromium (npx playwright install chromium).
import { chromium } from "playwright-core";

// Reads --flag value pairs, with defaults for throttling.
function parseArgs(argv) {
  const options = { bw: 1600, rtt: 100, cpu: 4, selector: "body", storage: "{}" };
  for (let i = 0; i < argv.length; i += 2) {
    const key = argv[i].replace(/^--/, "").replace("session-storage", "storage");
    options[key] = ["bw", "rtt", "cpu"].includes(key) ? Number(argv[i + 1]) : argv[i + 1];
  }
  return options;
}

// Groups CPU profile samples by file and function and returns the heaviest ones in milliseconds.
function topSelfTime(profile, limit) {
  const nodes = new Map(profile.nodes.map((node) => [node.id, node]));
  const totals = new Map();
  profile.samples.forEach((id, index) => {
    const { url, functionName } = nodes.get(id).callFrame;
    const key = `${url.replace(/^https?:\/\/[^/]+/, "") || "(native)"} :: ${functionName || "(anon)"}`;
    totals.set(key, (totals.get(key) ?? 0) + (profile.timeDeltas[index] ?? 0));
  });
  return [...totals.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit);
}

// Runs one throttled cold load and prints the report.
async function main() {
  const options = parseArgs(process.argv.slice(2));
  const browser = await chromium.launch({ args: ["--no-sandbox"], executablePath: options.chromium ?? process.env.CHROMIUM_PATH });
  const context = await browser.newContext({ viewport: { width: 1400, height: 900 }, serviceWorkers: "block" });
  await context.addInitScript((storage) => {
    for (const [key, value] of Object.entries(JSON.parse(storage))) sessionStorage.setItem(key, value);
  }, options.storage);
  const page = await context.newPage();
  const cdp = await context.newCDPSession(page);
  await cdp.send("Network.enable");
  await cdp.send("Network.setCacheDisabled", { cacheDisabled: true });
  await cdp.send("Network.emulateNetworkConditions", { offline: false, latency: options.rtt, downloadThroughput: options.bw * 1024, uploadThroughput: options.bw * 160 });
  await cdp.send("Emulation.setCPUThrottlingRate", { rate: options.cpu });
  await cdp.send("Profiler.enable");
  await cdp.send("Profiler.setSamplingInterval", { interval: 500 });
  await cdp.send("Profiler.start");
  await page.goto(options.url, { waitUntil: "commit" });
  await page.waitForSelector(options.selector, { timeout: 90000 });
  const { profile } = await cdp.send("Profiler.stop");
  const timing = await page.evaluate(() => ({
    fcp: Math.round(performance.getEntriesByName("first-contentful-paint")[0]?.startTime ?? 0),
    content: Math.round(performance.now()),
    slowest: performance.getEntriesByType("resource").map((e) => ({ name: e.name.replace(location.origin, "").slice(0, 90), start: Math.round(e.startTime), end: Math.round(e.responseEnd) })).sort((a, b) => b.end - a.end).slice(0, 8),
  }));
  console.log(`bw=${options.bw}KB/s rtt=${options.rtt}ms cpu=${options.cpu}x  FCP=${timing.fcp}ms  content=${timing.content}ms`);
  console.log("slowest to finish (start -> end ms):");
  timing.slowest.forEach((r) => console.log(`  ${String(r.start).padStart(5)} -> ${String(r.end).padStart(5)}  ${r.name}`));
  console.log("main-thread self time (ms):");
  topSelfTime(profile, 10).forEach(([key, micro]) => console.log(`  ${String(Math.round(micro / 1000)).padStart(5)}  ${key.slice(0, 100)}`));
  await browser.close();
}

main();
