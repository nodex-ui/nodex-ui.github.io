#!/usr/bin/env node
/**
 * Bootstrap a brand-new pure Nodex UI static/CDN-friendly project from scratch:
 * package.json, an `nodexui`-style facade over `@odoo/owl`, a minimal
 * esbuild-based build script, an entry point, and a browser example that
 * mounts a root component via an import map — no bundler required to try it.
 *
 * It covers the greenfield case for an Owl app or a plain Owl
 * component-library project (like base-ui) that has no GrapesJS canvas at
 * all. It is intentionally dependency-light and copyable into any repo's
 * scripts/ folder for reuse.
 *
 * Usage:
 *   node new-owl-project.mjs <target-dir> [options]
 *
 * Options:
 *   --name <pkg-name>       package.json name (default: derived from dir)
 *   --namespace <name>      Owl template namespace prefix (default: app)
 *   --owl-version <semver>  Exact @odoo/owl version to pin (default: 2.8.3)
 *   --facade <name>         Public Owl facade package/import name
 *                            (default: nodexui)
 *   --force                 Overwrite existing files instead of skipping
 *
 * Example:
 *   node new-owl-project.mjs ../my-owl-lib --name @acme/ui --namespace acme
 */

import { mkdirSync, writeFileSync, existsSync } from "node:fs";
import { join, basename, resolve } from "node:path";

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--force") args.force = true;
    else if (a === "--name") args.name = argv[++i];
    else if (a === "--namespace") args.namespace = argv[++i];
    else if (a === "--owl-version") args.owlVersion = argv[++i];
    else if (a === "--facade") args.facade = argv[++i];
    else args._.push(a);
  }
  return args;
}

function writeIfAllowed(path, content, force) {
  if (existsSync(path) && !force) {
    console.log(`skip (exists): ${path}`);
    return;
  }
  writeFileSync(path, content, "utf8");
  console.log(`wrote: ${path}`);
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const targetArg = args._[0];
  if (!targetArg) {
    console.error("Usage: node new-owl-project.mjs <target-dir> [options]");
    process.exit(1);
  }

  const target = resolve(targetArg);
  const pkgName = args.name || basename(target);
  const namespace = args.namespace || "app";
  const owlVersion = args.owlVersion || "2.8.3";
  const facade = args.facade || "nodexui";

  mkdirSync(target, { recursive: true });
  mkdirSync(join(target, "src", "owl"), { recursive: true });
  mkdirSync(join(target, "src", "components"), { recursive: true });
  mkdirSync(join(target, "scripts"), { recursive: true });
  mkdirSync(join(target, "examples"), { recursive: true });
  mkdirSync(join(target, "test"), { recursive: true });

  const packageJson = {
    name: pkgName,
    version: "0.1.0",
    type: "module",
    private: true,
    scripts: {
      build: "node scripts/build.mjs",
      dev: "node scripts/serve.mjs",
      test: "vitest run",
    },
    dependencies: {
      "@odoo/owl": owlVersion,
    },
    devDependencies: {
      esbuild: "^0.23.0",
      vitest: "^2.1.0",
      jsdom: "^25.0.0",
    },
  };

  writeIfAllowed(
    join(target, "package.json"),
    JSON.stringify(packageJson, null, 2) + "\n",
    args.force
  );

  // Facade: internal implementation dependency is @odoo/owl, re-exported
  // under the project's own public facade name so component source and
  // consumer apps never import @odoo/owl directly.
  writeIfAllowed(
    join(target, "src", "owl", "index.js"),
    `// Public Owl facade ("${facade}"). Internal implementation dependency
// is @odoo/owl, pinned to exactly ${owlVersion} in package.json.
// Component source, tests, and docs should import from this facade
// (or the published "${facade}" package name), never "@odoo/owl" directly.
export * from "@odoo/owl";
`,
    args.force
  );

  writeIfAllowed(
    join(target, "src", "components", "index.js"),
    `// Aggregate export of every pure Nodex UI component class.
// Add: export { ComponentName } from "./component-name/component-name.component.js";
`,
    args.force
  );

  writeIfAllowed(
    join(target, "src", "entry-owl.js"),
    `// Side-effect-free re-export of the public Owl facade, for the build's
// "owl" output target (dist/owl.esm.js-equivalent for this project).
export * from "./owl/index.js";
`,
    args.force
  );

  writeIfAllowed(
    join(target, "src", "entry-components.js"),
    `// Side-effect-free re-export of every pure Nodex UI component. Do not call
// autoMount() or mount anything here — consumers import and compose these
// themselves.
export * from "./components/index.js";
`,
    args.force
  );

  const buildScript = `import { build } from "esbuild";
import { mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const outdir = "dist";
mkdirSync(outdir, { recursive: true });

// Public Owl facade bundle, so consumers can \`import { Component } from
// "${facade}"\` without installing @odoo/owl themselves.
await build({
  entryPoints: ["src/entry-owl.js"],
  outfile: \`\${outdir}/owl.esm.js\`,
  bundle: true,
  format: "esm",
  minify: false,
});

// Pure Nodex UI component bundle. Consumers load this after the Owl facade.
await build({
  entryPoints: ["src/entry-components.js"],
  outfile: \`\${outdir}/${pkgName.replace(/[^a-z0-9]/gi, "-").toLowerCase()}.components.esm.js\`,
  bundle: true,
  format: "esm",
  minify: false,
  external: ["${facade}"],
});

// Concatenate every component's .xml templates into one templates file so
// consumers can fetch a single URL before mounting an Owl root.
const componentsDir = "src/components";
let templates = "";
for (const name of readdirSync(componentsDir)) {
  const xmlPath = join(componentsDir, name, \`\${name}.xml\`);
  try {
    const raw = readFileSync(xmlPath, "utf8");
    const inner = raw.replace(/^\\s*<templates[^>]*>/, "").replace(/<\\/templates>\\s*$/, "");
    templates += inner;
  } catch {
    // no .xml for this component yet — skip
  }
}
writeFileSync(\`\${outdir}/templates.xml\`, \`<templates xml:space="preserve">\${templates}</templates>\\n\`);

console.log("Build complete.");
`;
  writeIfAllowed(join(target, "scripts", "build.mjs"), buildScript, args.force);

  const serveScript = `import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join } from "node:path";

const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".xml": "application/xml" };
const root = process.cwd();

createServer(async (req, res) => {
  let path = req.url === "/" ? "/examples/index.html" : req.url.split("?")[0];
  try {
    const data = await readFile(join(root, path));
    res.writeHead(200, { "Content-Type": MIME[extname(path)] || "application/octet-stream" });
    res.end(data);
  } catch {
    res.writeHead(404);
    res.end("Not found");
  }
}).listen(8080, () => console.log("Dev server: http://localhost:8080"));
`;
  writeIfAllowed(join(target, "scripts", "serve.mjs"), serveScript, args.force);

  writeIfAllowed(
    join(target, "vitest.config.mjs"),
    `import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "jsdom",
  },
  resolve: {
    alias: {
      "${facade}": new URL("./src/owl/index.js", import.meta.url).pathname,
    },
  },
});
`,
    args.force
  );

  writeIfAllowed(
    join(target, "test", "owl-facade.test.js"),
    `import { describe, expect, it } from "vitest";
import { Component, mount, xml } from "${facade}";

describe("${facade} facade", () => {
  it("exposes the Owl API and mounts a tiny component", async () => {
    expect(Component).toBeTypeOf("function");
    expect(mount).toBeTypeOf("function");

    class Greeter extends Component {
      static template = xml\`<span t-esc="props.name"/>\`;
      static props = { name: String };
    }
    const target = document.createElement("div");
    document.body.appendChild(target);
    await mount(Greeter, target, { props: { name: "World" } });
    expect(target.textContent).toBe("World");
  });
});
`,
    args.force
  );

  const exampleHtml = `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>${pkgName}</title>
    <script type="importmap">
      {
        "imports": {
          "${facade}": "/dist/owl.esm.js",
          "${pkgName}/components": "/dist/${pkgName.replace(/[^a-z0-9]/gi, "-").toLowerCase()}.components.esm.js"
        }
      }
    </script>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="./index.js"></script>
  </body>
</html>
`;
  writeIfAllowed(join(target, "examples", "index.html"), exampleHtml, args.force);

  const exampleJs = `import { Component, mount, xml } from "${facade}";

class Root extends Component {
  static template = xml\`<div>Hello from ${namespace}</div>\`;
}

mount(Root, document.getElementById("root"));
`;
  writeIfAllowed(join(target, "examples", "index.js"), exampleJs, args.force);

  writeIfAllowed(
    join(target, ".gitignore"),
    `node_modules/\ndist/\n`,
    args.force
  );

  writeIfAllowed(
    join(target, "README.md"),
    `# ${pkgName}

Pure Nodex UI static project, scaffolded by new-owl-project.mjs.

## Develop

\`\`\`bash
npm install
npm run build
npm run test
npm run dev
# open http://localhost:8080
\`\`\`

## Structure

- \`src/owl/index.js\` — public Owl facade ("${facade}"), re-exports \`@odoo/owl\` pinned to ${owlVersion}.
- \`src/components/\` — pure Nodex UI components, one folder per component (\`<name>.component.js\`, \`<name>.xml\`, \`<name>.js\` static adapter, \`<name>.css\`). Use \`new-owl-component.mjs\` to scaffold new ones.
- \`scripts/build.mjs\` — esbuild bundles for the Owl facade, the component bundle, and concatenated \`.xml\` templates.
- \`test/\` — Vitest + jsdom. \`owl-facade.test.js\` is a smoke test for the facade; use \`new-owl-test.mjs\` to scaffold a mount test per component.
- \`examples/\` — browser example using an import map, no bundler required to try it.

## Adding a component

\`\`\`bash
node path/to/new-owl-component.mjs <slug> --dir src/components --namespace ${namespace} --facade ${facade} --register
node path/to/new-owl-test.mjs <slug> --dir src/components --facade ${facade} --namespace ${namespace}
\`\`\`
`,
    args.force
  );

  console.log(`\nScaffolded ${pkgName} at ${target}`);
  console.log(`\nNext steps:`);
  console.log(`  cd ${targetArg} && npm install && npm run build && npm run test && npm run dev`);
  console.log(`  Use new-owl-component.mjs --register to add real components under src/components/.`);
  console.log(`  Use new-owl-test.mjs to scaffold a mount test for each new component.`);
}

main();
