#!/usr/bin/env node
/**
 * Scaffold a Vitest test file that mounts a pure Nodex UI component the same way
 * base-ui's own test/owl-components.test.js does: load the component's own
 * <slug>.xml as the template source (no prior `npm run build` required),
 * mount a tiny Root that renders the component, and assert on the DOM.
 *
 * This assumes Vitest + jsdom (NodexUI's setup, and the common default for
 * Owl component libraries). If the target project uses a different test
 * runner, use this file as a reference and adapt the imports/assertions —
 * the mount-a-Root-with-inline-templates pattern is the part worth reusing.
 *
 * Usage:
 *   node new-owl-test.mjs <slug> [options]
 *
 * Options:
 *   --dir <path>          Components root the component lives under
 *                          (default: src/components)
 *   --test-dir <path>     Where to write the test file (default: test)
 *   --facade <name>       Owl import specifier (default: nodexui)
 *   --namespace <name>    Owl template namespace prefix (default: nodexui)
 *   --force               Overwrite an existing test file
 *
 * Example:
 *   node new-owl-test.mjs tooltip
 *   node new-owl-test.mjs data-table --namespace myui --test-dir tests
 */

import { mkdirSync, writeFileSync, existsSync } from "node:fs";
import { join, relative } from "node:path";

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--force") args.force = true;
    else if (a === "--dir") args.dir = argv[++i];
    else if (a === "--test-dir") args.testDir = argv[++i];
    else if (a === "--namespace") args.namespace = argv[++i];
    else if (a === "--facade") args.facade = argv[++i];
    else args._.push(a);
  }
  return args;
}

function toPascalCase(slug) {
  return slug
    .split(/[-_]/g)
    .filter(Boolean)
    .map((part) => part[0].toUpperCase() + part.slice(1))
    .join("");
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const slug = args._[0];
  if (!slug) {
    console.error("Usage: node new-owl-test.mjs <slug> [options]");
    process.exit(1);
  }

  const dir = args.dir || "src/components";
  const testDir = args.testDir || "test";
  const namespace = args.namespace || "nodexui";
  const facade = args.facade || "nodexui";
  const className = toPascalCase(slug);

  mkdirSync(testDir, { recursive: true });

  // ES import path is relative to the generated test file's own location
  // (<testDir>/<slug>.owl.test.js), so it must be computed from testDir.
  const componentImport = relative(testDir, join(dir, slug, `${slug}.component.js`)).replace(/\\/g, "/");
  const componentImportSpecifier = componentImport.startsWith(".") ? componentImport : `./${componentImport}`;
  // readFileSync below resolves via process.cwd(), which Vitest sets to the
  // project root regardless of the test file's own location — so this must
  // stay a plain project-root-relative path, not relative-to-testDir.
  const xmlProjectRelative = join(dir, slug, `${slug}.xml`).replace(/\\/g, "/");

  const testJs = `import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { Component, mount, xml } from "${facade}";
import { ${className} } from "${componentImportSpecifier}";

// Loads this component's own template directly, so the test doesn't depend
// on a prior build step or the full templates.xml bundle.
const templateXml = readFileSync(path.join(process.cwd(), "${xmlProjectRelative}"), "utf8");
const templates = templateXml.match(/<templates[^>]*>([\\s\\S]*)<\\/templates>/)[1].trim();

async function mountRoot(RootClass) {
  const target = document.createElement("div");
  document.body.appendChild(target);
  const app = await mount(RootClass, target, { templates: \`<templates>\${templates}</templates>\` });
  return { target, app };
}

describe("${className} (pure Nodex UI)", () => {
  it("mounts and renders default slot content", async () => {
    class Root extends Component {
      static components = { ${className} };
      static template = xml\`<${className}>Hello</${className}>\`;
    }
    const { target } = await mountRoot(Root);
    expect(target.querySelector(".${namespace}-${slug}")).toBeTruthy();
    expect(target.textContent).toContain("Hello");
  });

  // TODO: add assertions for this component's real props (variant/size/
  // disabled/etc.), events (onClick/onChange/onOpenChange callback props),
  // and any keyboard/focus behavior it owns.
});
`;

  const testPath = join(testDir, `${slug}.owl.test.js`);
  if (existsSync(testPath) && !args.force) {
    console.log(`skip (exists): ${testPath}`);
  } else {
    writeFileSync(testPath, testJs, "utf8");
    console.log(`wrote: ${testPath}`);
  }

  console.log(`\nNext steps:`);
  console.log(`  1. Fill in real prop/event/keyboard assertions once ${slug}.component.js has real behavior.`);
  console.log(`  2. Run the project's test command to confirm it passes.`);
}

main();
