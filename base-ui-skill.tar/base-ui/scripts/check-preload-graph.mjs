#!/usr/bin/env node
// Checks that index.html preloads every file in the static import graph of the given entry modules.
// A stale preload list silently loses the speed-up; a missing file brings back a serial round trip.
//
// Usage: node check-preload-graph.mjs --root <app dir> --html index.html --entry modules/Shell.js [--entry ...] [--alias @/=./]
//   --alias maps an import-map prefix to a folder relative to --root (default "@/=./").
import fs from "node:fs";
import path from "node:path";

const IMPORT_RE = /(?:^|\n)\s*(?:import|export)\s[^"'`;]*?from\s*["']([^"']+)["']|(?:^|\n)\s*import\s*["']([^"']+)["']/g;
const XML_RE = /new URL\(\s*["']([^"']+\.xml)["']\s*,\s*import\.meta\.url/g;

// Reads the command line into { root, html, entries, aliases }.
function parseArgs(argv) {
  const options = { root: ".", html: "index.html", entries: [], aliases: [["@/", "./"]] };
  for (let i = 0; i < argv.length; i += 2) {
    const [flag, value] = [argv[i], argv[i + 1]];
    if (flag === "--root") options.root = value;
    else if (flag === "--html") options.html = value;
    else if (flag === "--entry") options.entries.push(value);
    else if (flag === "--alias") options.aliases.push(value.split("="));
  }
  return options;
}

// Turns an import specifier into a file path under root, or null for bare/CDN specifiers.
function resolveSpecifier(options, from, specifier) {
  const alias = options.aliases.find(([prefix]) => specifier.startsWith(prefix));
  if (alias) return path.join(options.root, alias[1], specifier.slice(alias[0].length));
  if (specifier.startsWith(".")) return path.join(path.dirname(from), specifier);
  return null;
}

// Walks static imports (not dynamic import()) and Owl template XML references from one file.
function crawl(options, file, files, xmls) {
  if (files.has(file) || !fs.existsSync(file)) return;
  files.add(file);
  const source = fs.readFileSync(file, "utf8");
  for (const match of source.matchAll(IMPORT_RE)) {
    const target = resolveSpecifier(options, file, match[1] ?? match[2]);
    if (target) crawl(options, target, files, xmls);
  }
  for (const match of source.matchAll(XML_RE)) xmls.add(path.join(path.dirname(file), match[1]));
}

// Reports closure files that index.html never mentions, and exits non-zero if any are missing.
function main() {
  const options = parseArgs(process.argv.slice(2));
  const files = new Set();
  const xmls = new Set();
  options.entries.forEach((entry) => crawl(options, path.join(options.root, entry), files, xmls));
  const html = fs.readFileSync(path.join(options.root, options.html), "utf8");
  const missing = [...files, ...xmls].map((file) => path.relative(options.root, file)).filter((rel) => !html.includes(rel));
  missing.forEach((rel) => console.error(`not preloaded in ${options.html}: ${rel}`));
  if (missing.length) process.exit(1);
  console.log(`preload lists OK (${files.size + xmls.size} files)`);
}

main();
