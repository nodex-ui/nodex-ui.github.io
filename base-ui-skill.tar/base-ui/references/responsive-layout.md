# Responsive layout (`make it responsive`, `responsive layout`, `reflow`)

A responsive page is one layout that reflows through a fixed ladder of widths, not four separate
pages. The reference example is a magazine layout (header, nav, left rail, main with a featured
story and a popular grid, right rail, footer) shown at four widths. Use the same ladder and
named grid areas for any multi-region page; `references/page-layouts.md` says which layout to pick,
this file says how it reflows.

## Table of contents

- The breakpoint ladder
- Reference CSS (magazine example)
- How each region behaves
- Cross-cutting rules

## The breakpoint ladder

Mobile first: write the built-in styles for the narrowest screen, then add `min-width` queries that
only add or rearrange, never undo. Undoing earlier rules is what makes responsive CSS fragile.

| Step | Query | Columns | What changes |
| --- | --- | --- | --- |
| Mobile | base (no query) | 1 | Everything stacked: header, nav, main (featured, popular stacked), then rails and footer below |
| Tablet | `min-width: 480px` | 2 equal (`1fr 1fr`) | Header spans both columns; popular items sit in a row of cards |
| Laptop | `min-width: 768px` | 3: `200px 1fr 200px` | Fixed rails left and right, fluid main (`fixed rails, fluid main`); header, nav and footer span all three |
| Desktop | `min-width: 1024px` | 3, capped | `.layout` gets `max-width: 1200px; margin: 0 auto`; inside main the featured lead story sits beside the popular grid |

480/768/1024 match the built-in `sm`(576)/`md`(768)/`lg`(992) loosely but not exactly. When the page
already uses built-in utilities, either use the built-in breakpoints throughout, or use the
custom ladder throughout and keep built-in only for spacing; mixing two ladders in one component
produces dead zones where neither rule set applies.

## Reference CSS (magazine example)

Named `grid-template-areas` make the reflow readable: each step redraws the map and the markup
never changes. DOM order is the mobile reading order (header, nav, main, left, right, footer),
which is also the correct order for screen readers and keyboard focus.

```css
/* Mobile first: one stacked column. */
.layout {
  display: grid;
  grid-template-columns: 1fr;
  grid-template-areas: "header" "nav" "main" "left" "right" "footer";
  gap: 1rem;
}
.layout > header { grid-area: header; }
.layout > nav    { grid-area: nav; }
.layout > main   { grid-area: main; min-width: 0; }
.layout > .left  { grid-area: left; }
.layout > .right { grid-area: right; }
.layout > footer { grid-area: footer; }

/* 480px+: two columns, header spans both. */
@media (min-width: 480px) {
  .layout {
    grid-template-columns: 1fr 1fr;
    grid-template-areas:
      "header header"
      "nav    nav"
      "main   main"
      "left   right"
      "footer footer";
  }
}

/* 768px+: fixed rails, fluid main. */
@media (min-width: 768px) {
  .layout {
    grid-template-columns: 200px 1fr 200px;
    grid-template-areas:
      "header header header"
      "nav    nav    nav"
      "left   main   right"
      "footer footer footer";
  }
}

/* 1024px+: cap the width; the lead story splits beside the grid. */
@media (min-width: 1024px) {
  .layout { max-width: 1200px; margin: 0 auto; }
  .main   { display: grid; grid-template-columns: 2fr 1fr; gap: 1rem; }
  .main .featured { grid-column: 1; }
  .main .popular  { grid-column: 2; }
}
```

The grid areas above are reconstructed from the visible parts of the example (the tablet and
laptop rows were partly cut off), so the exact tablet arrangement of the rails is a sensible
default rather than a copy; adjust to the content.

## How each region behaves

- **Header**: always full width. At mobile, collapse the secondary actions (the example shrinks
  its second pill to a dot); keep the brand and one primary action.
- **Nav**: a row of links that shrinks to icon-only/dots on mobile; if it cannot fit, make it
  horizontally scrollable (`overflow-x: auto`) or move it into a `Sheet`/`Drawer` behind a menu
  button. On phones consider `references/bottom-menu.md` instead of a top nav.
- **Left / right rails**: hidden below 480px in the example's mobile state (they fall to the
  bottom of the stack); fixed 200px at 768px+. Give each rail `min-width: 0` and let long content
  wrap or scroll, not stretch the grid.
- **Main**: `min-width: 0` so wide children (tables, code) cannot blow the `1fr` track out.
  Featured story first, popular items after: stacked on mobile, a row of cards on tablet, a column
  or grid beside the lead on desktop.
- **Footer**: spans all columns at every step.

NodexUI parts: `Shell` handles the app-shell version of this (collapsing sidebar,
`docs/components/shell.md`); `Card` for featured/popular items; `Sheet`/`Drawer` for rails that
move off-canvas on small screens; `Resizable` only when the user must drag column widths.

## Cross-cutting rules

- **Test at the edges**, not at device names: 320, 479, 480, 767, 768, 1023, 1024 and 1440px. Bugs
  hide one pixel either side of a breakpoint.
- **Fluid inside the ladder**: use `minmax()`, `clamp()` and `fr` for sizes between breakpoints
  (`font-size: clamp(1rem, 2.5vw, 1.25rem)`), so the layout is never stuck at a fixed size for a
  300px-wide range.
- **Content decides breakpoints**: if a layout breaks at 900px, add a step there; the 480/768/1024
  ladder is a default, not a law.
- **Images and media**: `max-width: 100%; height: auto`, with `AspectRatio` or intrinsic
  `width`/`height` attributes to prevent layout shift.
- **Touch and pointer**: 44px minimum targets at every size; do not rely on hover to reveal
  navigation.
- **Viewport meta**: `<meta name="viewport" content="width=device-width, initial-scale=1">`
  (plus `viewport-fit=cover` if using safe-area insets); without it none of the media queries
  behave as intended on phones.
- **Verify in a browser**: resize the real page (or use devtools device mode) through the whole
  ladder and confirm no horizontal scrollbar at any width.
