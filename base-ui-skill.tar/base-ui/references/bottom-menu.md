# Mobile bottom menu (`add bottom menu` / `bottom nav` / `tab bar`)

NodexUI has no bottom-navigation component, so build it as one small Nodex component from `Icon` and
plain `<nav>` markup plus a few CSS rules. Six named styles are covered; they share the same
markup and differ only in CSS classes, so generate one component with a `variant` prop rather
than six copies. Icon names below were checked against `dist/icons/lucide.json`; re-check any you
swap in (`references/icons.md`).

## Table of contents

- Shared component
- Shared CSS
- The 6 styles
- Cross-cutting rules

## Shared component

Items are data, not markup: `{ id, label, icon, href }`. The active item comes from the router
hash/path (or a `value` prop), never from local click state, so reload and back-button agree.

```js
import { Component } from "nodexui";
import { Icon } from "nodexui";

// Bottom tab bar for phones: shows 3-5 destinations and highlights the current one.
export class BottomMenu extends Component {
  static template = "app.BottomMenu";
  static components = { Icon };
  static props = ["items", "value", "variant?", "onSelect?"];
}
```

```xml
<t t-name="app.BottomMenu">
  <nav t-attf-class="app-bottom-menu app-bottom-menu--{{props.variant || 'minimal'}}" aria-label="Primary">
    <t t-foreach="props.items" t-as="item" t-key="item.id">
      <a t-if="!item.fab" class="app-bottom-menu__item" t-att-href="item.href"
         t-att-class="{ 'is-active': item.id === props.value }"
         t-att-aria-current="item.id === props.value ? 'page' : undefined"
         t-on-click="() => props.onSelect and props.onSelect(item)">
        <Icon name="item.icon"/>
        <span class="app-bottom-menu__label" t-esc="item.label"/>
      </a>
      <button t-else="" type="button" class="app-bottom-menu__fab" t-att-aria-label="item.label"
              t-on-click="() => props.onSelect and props.onSelect(item)">
        <Icon name="item.icon"/>
      </button>
    </t>
  </nav>
</t>
```

`Icon` takes `name` (verified in `docs/components/icon.md`); props are JS expressions, so
`name="item.icon"` reads the data and a literal must be quoted, `name="'house'"` (`syntax.md`).

## Shared CSS

```css
.app-bottom-menu {
  position: fixed; inset: auto 0 0 0; z-index: 1030;
  display: flex; align-items: center; justify-content: space-around;
  padding: .5rem .5rem calc(.5rem + env(safe-area-inset-bottom));
  background: var(--bs-body-bg); border-top: 1px solid var(--bs-border-color);
}
.app-bottom-menu__item {
  display: grid; justify-items: center; gap: .125rem; min-width: 3.5rem; min-height: 2.75rem;
  color: var(--bs-secondary-color); font-size: .75rem; text-decoration: none;
}
.app-bottom-menu__item.is-active { color: var(--bs-primary); font-weight: 600; }
@media (min-width: 992px) { .app-bottom-menu { display: none; } }
```

Give the page `padding-bottom: calc(4rem + env(safe-area-inset-bottom))` so the bar never covers
content. Add `viewport-fit=cover` to the viewport meta tag, otherwise `env(safe-area-inset-bottom)`
is 0 on notched phones.

## The 6 styles

Item sets in the picture: Home / Explore / Projects / Saved / Profile, and Home / Search / Files
or Projects / Alerts or Inbox / Profile. Suggested icons: `house`, `compass`, `folder`,
`bookmark`, `circle-user`, `search`, `bell`, `message-square`, `chart-no-axes-column`, `plus`.

1. **Minimal Clean** (`--minimal`): rounded white bar, soft shadow, 5 icon+label items; active item
   gets the primary color and a 4px dot under the label (`.is-active::after`).
2. **Bottom Line** (`--line`): flat bar; active item gets a 2-3px gradient/primary underline
   (`.is-active::after { height: 3px; width: 1.5rem; border-radius: 2px }`) plus bold label.
3. **Glassmorphism** (`--glass`): translucent bar `background: color-mix(in srgb,
   var(--bs-body-bg) 55%, transparent); backdrop-filter: blur(16px) saturate(160%)`, gradient
   border, rounded 1.5rem, floating with `inset: auto .75rem .75rem`; active item is a lighter
   rounded pill. Needs a colorful background behind it to read as glass; add a solid fallback
   under `@supports not (backdrop-filter: blur(1px))`.
4. **Expanding Tab** (`--expand`): icon-only items; the active one grows (`flex: 2`) to reveal its
   label beside the icon with a tinted background and bottom border. Animate `flex-grow`
   and label `opacity`/`max-width`, not width.
5. **Centre FAB** (`--fab`): four items plus a raised round `+` button in the middle
   (`.app-bottom-menu__fab`: 3.5rem circle, `margin-top: -1.75rem`, primary/gradient background,
   shadow). Put the FAB item in the middle of `items` with `fab: true`; the FAB is an action
   (create), not a destination, so it is a `<button>` and never takes `is-active`.
6. **Gradient Bold** (`--bold`): full-bleed gradient bar (`linear-gradient(90deg, primary,
   purple)`), white icons/labels; active item is a white rounded pill with primary-colored
   content; optional white circular FAB in the center like style 5. Check text contrast on both
   ends of the gradient.

## Cross-cutting rules

- **3 to 5 destinations**; more belongs in a "More" item that opens a `Sheet`/`Drawer`.
- **Touch targets** at least 44x44px (`min-height: 2.75rem`), labels always visible except in the
  expanding style, where the inactive `aria-label` must still be set.
- **Semantics**: a `<nav aria-label>` of links with `aria-current="page"`; the FAB is a labelled
  `<button>`. Icons are decorative when a visible label exists.
- **Mobile only**: hide at `lg` and up, where the app uses `Shell`/`Sidebar` instead
  (`docs/components/shell.md`); render both from the same `items` array.
- **Theming**: colors from `--bs-*` variables so dark mode works; gradients derive from
  `--bs-primary`.
- **Keyboard**: when the on-screen keyboard opens, the fixed bar can float over inputs; hide it
  while an input is focused (`focusin`/`focusout` on the document) in forms-heavy screens.
- **Capacitor/PWA**: honor safe areas (above) and avoid overlapping the Android gesture bar; see
  `references/capacitor.md`.
