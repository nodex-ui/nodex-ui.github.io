# Scroll patterns (`add <pattern> scroll`)

Users name a scroll behavior ("sticky header", "scroll snap", "parallax", "infinite scroll"). Pick
the recipe below. Prefer native CSS first: it runs off the main thread, needs no JS, and survives
Nodex re-renders. Reach for JS (`IntersectionObserver`, never a `scroll` listener that reads layout)
only where CSS cannot do the job. Wire JS in `onMounted` and tear it down in `onWillUnmount`.

## Table of contents

- Picking a pattern
- The 9 patterns
- Cross-cutting rules

## Picking a pattern

| Behavior | Pattern | Tool |
| --- | --- | --- |
| Headers pin, then hand off to the next | Sticky positioning | CSS |
| Panels lock into place | Scroll snap | CSS |
| Fades in on enter | Scroll triggered | `IntersectionObserver` (or CSS `animation-timeline: view()`) |
| More loads near the end | Infinite scroll | `IntersectionObserver` sentinel |
| Progress follows scroll | Scroll driven | CSS `animation-timeline: scroll()` |
| Image grows as it passes | Zoom on scroll | CSS `animation-timeline: view()` |
| Background moves slower | Parallax | CSS `animation-timeline` / transform |
| Vertical scroll → sideways track | Horizontal scroll | sticky + translateX, or native `overflow-x` |
| Steps play, scene stays put | Scrollytelling | sticky stage + step observers |

## The 9 patterns

### 1. Sticky positioning
`position: sticky; top: 0` on each section heading inside its own section container; the next
heading pushes the previous out (the hand-off). Needs no ancestor with `overflow: hidden/auto`
between the element and the scroller, or sticky silently stops working. App headers: `ShellHeader`
already sticks; offset a second sticky bar with `top: var(--header-height)`.

### 2. Scroll snap
Container: `overflow-y: auto; scroll-snap-type: y mandatory; height: 100dvh`. Child panels:
`scroll-snap-align: start; min-height: 100dvh`. Use `proximity` instead of `mandatory` when panels
can be taller than the viewport, otherwise users cannot reach the middle of tall content. Carousels
use `x` snapping, see `Carousel`.

### 3. Scroll triggered (fade in on enter)
Start state class `opacity: 0; transform: translateY(1rem)`, `.is-visible` transitions to normal.
One shared `IntersectionObserver({ threshold: 0.15 })`, `unobserve` after first reveal. Or pure CSS:
`animation: reveal linear both; animation-timeline: view(); animation-range: entry 0% entry 40%`.
Wrap in `@media (prefers-reduced-motion: no-preference)`.

### 4. Infinite scroll
Render the list plus a 1px sentinel element at the end; an `IntersectionObserver` with
`rootMargin: "400px"` calls `loadMore()` when it intersects. Guard with `state.loading` and
`state.done` so a fast scroll does not fire duplicate pages; show `Skeleton` rows while loading;
dedupe by id when appending. For 1000+ rows add windowing or offer `Pagination` instead.

### 5. Scroll driven (progress follows scroll)
Reading-progress bar: fixed `div` with `transform-origin: left; animation: grow linear;
animation-timeline: scroll(root)` and `@keyframes grow { from { transform: scaleX(0) } to {
transform: scaleX(1) } }`. Browsers without `animation-timeline` just show no bar; gate with
`@supports (animation-timeline: scroll())`, no JS fallback needed.

### 6. Zoom on scroll
Image `animation: zoom linear both; animation-timeline: view(); animation-range: cover 0% cover
100%` with `scale(1) → scale(1.25)`, inside a wrapper with `overflow: hidden` (`AspectRatio`) so
growth stays clipped. Animate `transform` only, never width/height.

### 7. Parallax
Background layer moves slower than content: `animation: drift linear both; animation-timeline:
scroll()` translating `translateY(0) → translateY(-20%)`, layer taller than its frame
(`inset: -20% 0`). Keep the speed difference small and honor `prefers-reduced-motion` (disable it).
Avoid `background-attachment: fixed`; it is broken or janky on iOS.

### 8. Horizontal scroll (vertical → sideways)
Tall outer section (`height: 300vh`), inner `position: sticky; top: 0; height: 100dvh;
overflow: hidden`, a flex track translated with `animation: slide linear both;
animation-timeline: scroll()` on the outer section (`translateX(0) → translateX(calc(-100% +
100vw))`). If the user only wants a swipeable row, use native `overflow-x: auto` with scroll snap
instead; it is accessible by default.

### 9. Scrollytelling
Sticky stage (`position: sticky; top: 0; height: 100dvh`) holding the visual; beside or above it a
column of step blocks (`min-height: 80vh`). One `IntersectionObserver` (`rootMargin: "-50% 0px
-50% 0px"`) sets `state.step` to the step crossing the viewport middle; the stage re-renders from
`state.step` (Nodex `useState`). Steps trigger discrete states, scroll position does not drive
them, so the scene stays put and stays testable.

## Cross-cutting rules

- **Reduced motion**: every animated pattern (3, 5, 6, 7, 8, 9) must be disabled or made static
  under `@media (prefers-reduced-motion: reduce)`.
- **Animate `transform` and `opacity` only**; layout properties cause jank.
- **Scroller identity**: inside `Shell`, the scrolling element is usually `ShellContent`, not
  `window`. Pass it as the observer `root` and as the scroll-timeline source
  (`scroll(nearest)`), or the pattern appears to do nothing.
- **Cleanup**: disconnect observers in `onWillUnmount`; Nodex re-mounts pages on navigation.
- **Mobile**: use `dvh` not `vh`; test iOS Safari (sticky and snap quirks).
- **Don't hijack scroll**: no `wheel` listeners that call `preventDefault`; users lose native
  momentum and keyboard/assistive scrolling.
