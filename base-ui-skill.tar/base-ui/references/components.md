# Use/make a component (`use <component>` / `make <component>`)

Never invent a prop, event, or sub-component name from the English component name alone — always
resolve it against one of the sources below first.

## Step 1 — resolve component metadata from the shipped registry

Every `nodexui` install — npm or CDN — ships `dist/nodexui.registry.json`, a machine-readable
manifest of every one of the 74 components. Find it at, in order of likelihood:

1. In the NodexUI source repo: `dist/` is gitignored and may be absent — run `npm run build` first, or read the
   source `src/registry/nodexui.registry.json` and the `src/components/*/*.xml` templates directly.
2. `node_modules/nodexui/dist/nodexui.registry.json` (npm install)
3. The pinned CDN URL, e.g. `https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/nodexui.registry.json`
   — use the version resolved by `SKILL.md`'s "Pin the `nodexui` version once"
   section, not a guess.

Each entry looks like this (real example, `dialog`):

```json
{
  "name": "dialog",
  "type": "owl",
  "attributes": ["b-dialog-content", "b-dialog-trigger", "b-ui", "b-att-open", "..."],
  "events": ["nodexui:close", "nodexui:open"],
  "owlComponents": ["Dialog", "DialogTrigger", "DialogContent", "DialogHeader", "DialogFooter", "DialogTitle", "DialogDescription", "DialogClose"],
  "templateName": "nodexui.Dialog"
}
```

This tells you, without any other file: the exact static `b-*`/`b-att-*` attribute names, the exact
`nodexui:*` events it emits, and the exact pure Nodex UI class names to import for a compound component —
never guess a sub-component name like `DialogFooter` vs `DialogActions`, look it up here.

Human-readable usage docs live in `docs/components/<name>.md` (one per component, shipped in the npm
package too, `docs/components/` on the CDN) — read the matching page for examples after resolving
the exact API from the registry/templates, which stay the ground truth. In the NodexUI source repo the
component source is `src/components/<name>/` (`<name>.component.js`, `<name>.xml`, `<name>.js`).

Match the user's requested component name against the `name` field (kebab-case). If nothing matches
closely, say so rather than inventing a component — don't build a "modal" from scratch when `dialog`
already exists.

## Step 2 — resolve exact props/slots from the shipped templates

`dist/nodexui.templates.xml` ships with every install too (same two resolution paths as Step 1: local
`node_modules` or the pinned CDN `.../dist/nodexui.templates.xml`). It contains the *real* Nodex template
for every component, which tells you exactly which props/slots/handlers the component actually reads
— this is real usage, not prose that can go stale.

Find the block for a component by its `templateName` from Step 1 (e.g. search for
`t-name="nodexui.Dialog"` in the file) and read until the matching `</t>`. For example, `nodexui.Button`
shows:

```xml
<t t-name="nodexui.Button">
  <a t-if="props.href" t-att-href="props.href" ...>
    <Icon t-if="props.icon &amp;&amp; iconPosition !== 'end'" name="props.icon"/>
    <span t-if="props.label" t-esc="props.label"/>
    <t t-else="" t-slot="default"/>
    ...
  </a>
</t>
```

From this alone you can read off real facts without any other source: `Button` accepts `href` (renders
as a link instead of a button), `icon` + an icon-position concept, `label` **or** a default slot (not
both), and forwards `style`. Do the same lookup for every prop/slot/event you plan to use before
writing code — the template is ground truth for what actually renders.

## Step 3 — pick pure Nodex UI vs static markup

Write attribute syntax per `syntax.md` (string props need inner quotes: `variant="'outline'"`).

See `SKILL.md` §"Picking the right API" — default to pure Nodex UI inside any app scaffolded by this
skill (every scaffold is a Nodex app). Compound components (Dialog, Card, Tabs, DropdownMenu, ...)
export a root plus sub-components; Step 1's `owlComponents` list is the exact, authoritative export
list — use those names verbatim.

### Pure Nodex UI example

```js
import { Component } from "nodexui"; // or "nodexui" in an npm/bundler app
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, Button } from "nodexui";

/** Confirmation dialog that asks the user before deleting an item. */
class DeleteConfirm extends Component {
  static template = "app.DeleteConfirm";
  static components = { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, Button };
  static props = { onConfirm: Function };
}
```

```xml
<t t-name="app.DeleteConfirm">
  <Dialog>
    <DialogTrigger>
      <Button variant="'destructive'" label="'Delete'"/>
    </DialogTrigger>
    <DialogContent>
      <DialogHeader><DialogTitle>Delete this item?</DialogTitle></DialogHeader>
      <Button variant="'destructive'" label="'Confirm'" onClick="() => props.onConfirm()"/>
    </DialogContent>
  </Dialog>
</t>
```

### Static markup example (only for non-component targets)

```html
<button b-ui="button" b-att-variant="destructive" type="button" data-bs-toggle="modal" data-bs-target="#delete-modal">
  Delete
</button>
```

Static attribute names (`b-att-variant`, `b-att-size`, ...) come from Step 1's `attributes` list —
don't invent camelCase-to-kebab conversions the adapter doesn't actually read.

## Step 4 — apply the coding rule

One short, plain-language comment per component/function you write (see `SKILL.md`). Don't nest a
render-helper function inside the component class unless it's promoted to a real reusable
utility — Nodex UI components should stay flat: `setup()` plus any lifecycle hooks, no ad hoc nested
closures duplicating template logic.

## Step 5 — verify

Confirm every prop/event/sub-component name you used exists in what you actually read in Steps 1-2
— not from memory, and not from a doc that might have drifted from the shipped registry/templates.

## Recent API changes worth knowing (1.1.x)

These trip people up because older examples and memory predate them. Confirm against the registry/templates, but expect:

- **Outlined form controls (1.1.5).** `Input`, `Textarea`, `NativeSelect`, `Combobox`, `DatePicker`, `Select` and `InputGroup` draw their own Material-style label (resting inside, floating onto the border on focus/fill). Pass `label`, `supportingText`, `errorText`, `invalid` (plus `leadingIcon`/`trailingIcon`/`maxLength` where they exist) as props on the control. `labelBackground` (any CSS colour) matches the floating label's cut-out to the surrounding surface (cards, dialogs, dark panels). Static `b-ui` adapters are unchanged.
- **`Field` no longer renders its own label/error (1.1.5).** `Field` accepts `label`, `description`, `error`, `invalid` and hands them to the control inside it. For checkbox/radio-style fields use `FieldLabel` / `FieldError` explicitly. Don't wrap an outlined control in a separate `<label>` — you'll get a duplicate label.
- **`ApiDoc` (1.1.3).** Renders an OpenAPI 3 document (`src` or `spec`, plus `serverUrl`, `tryIt`, `authorize`, `theme`, `languages`, `height`...; events `nodexui:load`/`nodexui:error`/`nodexui:navigate`). Language logos ship in `dist/apidoc/img/`; set `assetBase` if serving them elsewhere. Page: `docs/components/apidoc.md`.
- **Global is `window.thebase` (1.1.0).** `window.NodexUI` still works but is deprecated (removed in 2.0.0): write `thebase.mountAll(...)`, `thebase.theme.set(...)`. The ESM `NodexUI` export is unaffected.
- **Internal CSS class prefix is `b` (1.2.0; was `bu` in 1.1.4–1.1.7)**, not `nodexui`. `bu-*` classes and `--bu-*` variables no longer exist. Don't target old `nodexui-*` classes in app CSS; prefer component props/`style`.
- **`Tabs` parts are `Tabs`/`TabsList`/`TabTrigger`/`TabsContainer`/`TabContent`** (0.0.12 restyle): `TabsList variant="'line'"` for underline, `orientation="'vertical'"` on `Tabs`; panels stay mounted and have no default border. Static: `b-att-variant="line"` on the host, wrap `[b-tab]` buttons in their own `<div>`.
- **`Toast` (0.0.11–0.0.12).** Starts hidden; set `open`. Props `delay` (default 3000, `0` = no auto-hide) and `position` (`top-left|top-right|bottom-left|bottom-right`); `<t t-set-slot="action">` slot; static markup uses `.b-toast-content` / `.b-toast-actions`.
- **`Button`** gained `unstyled`, `attrs`, `getRef`; `href` renders an `<a>`. **`style`** (string or object) is accepted next to `className` on almost every component.
- **`useTip` (1.1.6)** on outlined controls and `Field`: `useTip="1"` moves helper text into an info-icon tooltip. Focus ring is unified on `--b-primary`.
- **Tokens/classes:** `--b-*` custom properties (0.0.11) and `b-*` classes (0.0.11/1.1.4) replace `--nodexui-*`/`nodexui-*`.
- **One bundle (since 1.0):** `nodexui` maps to `dist/nodexui.esm.js`; `nodexui.owl.*` and `nodexui.components.esm.js` no longer exist. Nested components fall back to globally registered NodexUI components, so a missing `static components` entry no longer crashes.
- **`window.thebase.analytics`/`nodexui/analytics` and `nodexui/pwa`** are separate optional entries, not in the main bundle.
