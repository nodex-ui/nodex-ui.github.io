# NodexUI syntax cheat sheet (1.1.x)

Read this before emitting any component markup. It records the *shape* of valid NodexUI code so
you get the syntax right the first time; the registry/templates (see `components.md`) stay the
ground truth for the exact prop list of any one component. If a rule here conflicts with what
the shipped `docs/components/<name>.md` or registry says, trust the shipped files and say so.

## Contents
1. Pure Nodex UI template syntax (props are JS expressions)
2. Static `b-ui` syntax
3. Naming rules for compound components
4. Form controls (outlined fields, `Field`, `useTip`)
5. Overlays and open state
6. Tabs, Toast, Select, Button quick forms
7. Classes, tokens, globals
8. Mistakes that look right but fail

## 1. Pure Nodex UI template syntax

Templates are Nodex XML. Every attribute on a component tag is a **JavaScript expression**, not a
string, so literal strings need their own quotes inside the attribute:

| You want | Write | Not |
| --- | --- | --- |
| string prop | `variant="'outline'"`, `label="'Save'"` | `variant="outline"` (reads a variable named `outline`) |
| boolean | `disabled="true"` | `disabled` / `disabled="disabled"` |
| number | `maxLength="200"`, `rows="3"`, `delay="0"` | `maxLength="'200'"` |
| state value | `value="state.name"`, `open="state.open"` | `value="{{state.name}}"` |
| array/object | `options="[{value:'a',label:'A'}]"`, `style="{ color: 'red' }"` | JSON in quotes |
| callback | `onClick="() => state.open = true"`, `onChange="(v) => state.value = v"` | `t-on-click` on a component tag (works only on plain DOM elements) |

- **Plain text children are real text**: `<Button>Save</Button>`, `<TabTrigger value="'a'">Account</TabTrigger>`. Prefer `label="'Save'"` for a button whose only content is text; use children when you need an icon/spinner next to it.
- **Plain HTML elements keep ordinary attributes**: `<div class="d-flex gap-2">`, `<span class="fw-medium">`. Only component tags take expression-valued props.
- **Named slots**: `<t t-set-slot="action"> ... </t>` inside the component (Toast `action`, DataTable `toolbarActions`).
- **Directives on DOM elements**: `t-on-click="onSave"`, `t-if`, `t-else`, `t-foreach="items" t-as="item" t-key="item.id"`, `t-att-class`, `t-esc`, `t-out`. `t-out` content needs `markup()` from `nodexui` or it renders as escaped text.
- A raw JS global inside an expression compiles to `ctx.<Name>` (e.g. `String(x)` throws). Move the conversion into a component getter/method.
- Use strict XML: close every tag (`<Input/>`, `<br/>`), quote every attribute.
- `style` accepts a CSS string **or** an object (`style="{ maxWidth: '24rem' }"`) on almost every component; `className` is always a string expression (`className="'w-100 mt-3'"`).
- Imports: `import { Component, mount, useState, xml } from "nodexui"` (browser import map) or `from "nodexui"` (npm). Never `@odoo/owl`. Templates must be loaded and passed to `mount(Root, el, { templates })`.

Minimal component:

```js
import { Component, useState, xml } from "nodexui";
import { Button, Input } from "nodexui";

/** Lets the user type a name and shows a greeting once they press the button. */
export class Greeter extends Component {
  static components = { Button, Input };
  static template = xml`
    <div class="d-grid gap-3" style="max-width: 24rem">
      <Input label="'Your name'" value="state.name" onInput="(v) => state.name = v"/>
      <Button label="'Greet'" onClick="() => state.greeted = true"/>
      <p t-if="state.greeted">Hello, <t t-esc="state.name"/>!</p>
    </div>`;
  setup() {
    this.state = useState({ name: "", greeted: false });
  }
}
```

(`static template = xml\`...\`` is fine for small components; an app with an external `.xml`
uses `static template = "app.Name"`. `static components` is optional thanks to the global
fallback, but list what you use in shared code.)

## 2. Static `b-ui` syntax

Attribute names are all `b-…`; the old `data-nodexui`, `nodexui-component`, bare `nodexui="…"` and `data-*` option names no longer work.

| Purpose | Attribute | Example |
| --- | --- | --- |
| mount a component | `b-ui="<slug>"` | `<button b-ui="button">` |
| option / state | `b-att-<kebab-name>="value"` | `b-att-variant="outline"`, `b-att-size="sm"`, `b-att-icon-position="end"`, `b-att-state="open"`, `b-att-delay="0"`, `b-att-position="bottom-right"` |
| compound part marker | `b-<part>` (no value) | `b-card-body`, `b-dialog-panel`, `b-select-item`, `b-field-label`, `b-tab="id"` / `b-panel="id"` |
| icon | `<span b-icon="search" b-icon-size="1rem">` | name must exist in `lucide.json` |
| theme | `<html b-theme="dark">` | |
| genuine built-in interop | `data-bs-*` | only where the built-in JS needs it |

- Values are plain strings — **no extra quotes** (`b-att-variant="outline"`).
- The static component list per slug and its exact attributes/events is `registry.components[].attributes/events`; events are DOM `CustomEvent`s named `nodexui:change`, `nodexui:open`, `nodexui:close` (`event.detail.value`).
- Handles after mount: `element.NodexUIToast.show()`, `element.NodexUI<Name>` for others.
- The bundle auto-mounts `[b-ui]`/`[b-icon]` on `DOMContentLoaded`; call `thebase.mountAll(root)` after injecting markup. Browser global is `window.thebase` (`window.NodexUI` is deprecated, removed in 2.0.0).
- Static adapters enhance markup you author; they do **not** inject internals a pure Nodex UI template adds (e.g. accordion chevron). If a static docs page says so, author the markup yourself.
- `Dialog`/`Sheet`/`Drawer`: `<div b-ui="dialog" id="x" b-att-trigger="[b-att-trigger='#x']"><div b-dialog-panel>…<button b-dialog-close>`.

## 3. Naming rules for compound components

Take names verbatim from the registry `owlComponents`; they are not always the obvious ones.

- `Card` → `CardHeader`, `CardTitle`, `CardDescription`, `CardBody` (**Body**, not Content), `CardFooter`.
- `Dialog` → `DialogTrigger`, `DialogContent`, `DialogHeader`, `DialogTitle`, `DialogDescription`, `DialogFooter`, `DialogClose`.
- `Tabs` → `TabsList`, `TabTrigger`, `TabsContainer`, `TabContent` (singular `Tab…` for the trigger and panel, plural for list/container).
- `Select` → `SelectTrigger`, `SelectContent`, `SelectItem`. `DropdownMenu` → `DropdownMenuTrigger/Content/Item/Label/Group/Separator/Shortcut/Sub/SubTrigger/SubContent`.
- `Field` → `FieldSet`, `FieldLegend`, `FieldGroup`, `FieldLabel`, `FieldDescription`, `FieldError`, `FieldSeparator`, `FieldContent`, `FieldTitle`.
- Sidebar parts (`SidebarMenuButton`, …) and sub-parts are listed under the parent's `owlComponents`, not as top-level registry entries.
- Icons: `<Icon name="'search'"/>` or the generated `<IconSearch/>` from `nodexui/icons` / `nodexui/icons` (not in the main bundle).

## 4. Form controls

Since 1.1.5 `Input`, `Textarea`, `NativeSelect`, `Combobox`, `DatePicker`, `Select` draw their own outlined label — **do not wrap them in a separate `<label>`** (you would get two labels).

```xml
<Input label="'Email'" value="state.email" onInput="(v) => state.email = v"
       supportingText="'We never share it'" leadingIcon="'mail'"/>
<Input label="'Email'" errorText="'Enter a valid email'"/>      <!-- errorText replaces supportingText, sets aria-invalid -->
<Textarea label="'Message'" maxLength="200"/>                   <!-- shows n/200 counter -->
<Select label="'Role'" value="state.role" onChange="(v) => state.role = v">
  <SelectTrigger>Owner</SelectTrigger>
  <SelectContent><SelectItem value="'owner'">Owner</SelectItem></SelectContent>
</Select>
```

- Props: `label`, `supportingText`, `errorText`, `invalid`, `useTip`, `labelBackground`, `leadingIcon`/`trailingIcon`, `maxLength`, `placeholder`, `disabled`, `readonly`, `id`.
- `useTip="1"` (Number) hides helper text and shows it in a tooltip on an info icon; `errorText` always stays visible.
- `labelBackground="'#fff'"` (any CSS colour) when the field sits on a surface that is not the default field background (dark card, dialog).
- Callbacks: `Input`/`Textarea` `onInput(value, event)` and `onChange(value, event)`; other controls `onChange(value)`. Controlled `value` is never mutated by the component.
- `Field` takes `label`, `labelBackground`, `description`, `useTip`, `error`, `invalid` and hands them to the **one** control inside it (a control's own props win). `Field` no longer renders a standalone label: for `Checkbox`/`RadioGroup`/`Switch` use `FieldLabel for="'id'"` + `FieldDescription`, with `orientation="'horizontal'"` on the `Field`.
- `Label` and `FieldLabel` take `for` (not `htmlFor`) — the Card doc page still shows `htmlFor`, which is stale.
- A `NativeSelect`/`<select>` `value` does not reliably select an option that arrives later through a slot/`t-foreach`; set `t-att-selected` on each `<option>` against state instead.
- Static equivalents are unchanged and have no outlined label: `<div b-ui="field"><label b-field-label for="x">…</label><input b-ui="input" id="x"></div>`.

## 5. Overlays and open state

`Dialog`, `AlertDialog`, `Sheet`, `Drawer`, `Collapsible`, `Toast`, `Pwa` (and `Sidebar`) share one pattern (`Popover`/`HoverCard`/`Tooltip` do not — check their doc page):

- Uncontrolled: `defaultOpen="true"` (or just omit); trigger sub-component toggles it.
- Controlled: `open="state.open" onOpenChange="(v) => state.open = v"`. The static-only `state` prop (`"open"`/`"on"`/`"active"`) is also accepted.
- `Toast` never shows on mount: set `open` true after load. `delay` ms (default 3000, `0` = stay), `position="'bottom-right'"` fixes it to a corner, `action` slot sits beside the close button.
- Tooltip/Popover use real `bootstrap.Tooltip`/`bootstrap.Popover` that render their popup in `document.body`, so query `document.body` (not the trigger) in tests.

## 6. Quick forms of the most-used parts

```xml
<!-- Button: label OR children; icon + iconPosition; href turns it into <a> -->
<Button variant="'outline'" size="'sm'" icon="'plus'" label="'New'" onClick="() => this.add()"/>
<Button size="'icon'" icon="'trash'" ariaLabel="'Delete'" variant="'destructive'"/>
<Button href="'/docs'" label="'Docs'"/>

<!-- Tabs: segmented pill by default, variant 'line' for underline -->
<Tabs defaultValue="'a'" onChange="(v) => state.tab = v">
  <TabsList variant="'line'"><TabTrigger value="'a'">A</TabTrigger><TabTrigger value="'b'">B</TabTrigger></TabsList>
  <TabsContainer><TabContent value="'a'">…</TabContent><TabContent value="'b'">…</TabContent></TabsContainer>
</Tabs>

<!-- Toast with action slot -->
<Toast open="state.open" onOpenChange="(v) => state.open = v" position="'bottom-right'">
  <div class="fw-medium">Saved</div>
  <t t-set-slot="action"><Button size="'sm'" variant="'outline'" label="'Undo'"/></t>
</Toast>
```

Button `variant`: `default|outline|ghost|destructive|secondary|link`; `size`: `default|xs|sm|lg|icon|icon-xs|icon-sm|icon-lg`. Also `unstyled`, `attrs` (object spread onto the element), `getRef`.

Static: `<button b-ui="button" b-att-variant="outline" b-att-size="sm" b-att-icon="plus" b-att-icon-position="end">`; tabs `<div b-ui="tabs" b-att-variant="line"><div><button b-tab="a">A</button></div><section b-panel="a">…</section></div>` (wrap triggers in their own `<div>` or the host becomes the tablist and squeezes panels); toast `<div b-ui="toast" b-att-delay="3000"><div class="b-toast-content">…</div><div class="b-toast-actions"><button b-toast-close>Close</button></div></div>`.

## 7. Classes, tokens, globals

- Component CSS classes are `b-*` (was `nodexui-*` before 0.0.11); tokens are `--b-*` (was `--nodexui-*`). Don't write app CSS against the old names; prefer props, `className` with built-in utilities (`d-flex gap-2 w-100`), and `style`.
- Theme: `<html b-theme="dark">`, `thebase.theme.set("dark")` / `thebase.theme.set({ primary: "#0057d8", radius: "0.5rem" })`.
- Public helpers: `cn(...)` and `mergeStyle(...)` exported from `nodexui`.
- Pin the version in production (`@1.3.0` or `@1`), never `@latest`.

## 8. Mistakes that look right but fail

1. `variant="outline"` on a component tag — missing inner quotes.
2. `<Button disabled>` — must be `disabled="true"`.
3. `CardContent`, `TabsTrigger`, `TabsContent`, `DialogActions` — these names do not exist; see §3.
4. `<label>` wrapped around an outlined `Input`/`Select` — duplicate label; use the control's `label` prop or `Field`.
5. `t-on-click` on a component tag — use the `onClick` prop.
6. Static markup with `data-nodexui…`/`data-variant` — use `b-ui` / `b-att-*`.
7. Passing a child `<Icon>` into `SidebarTrigger` — it renders its own icon; pass `icon="'name'"`.
8. Importing `@odoo/owl`, or loading `nodexui.owl.*`/`nodexui.components.esm.js` — those no longer exist; everything is `dist/nodexui.esm.js`.
9. Toast/overlay that "never appears" — nothing set `open`/`.show()`; toasts start hidden.
10. Using `window.NodexUI` in new code — use `window.thebase`.
