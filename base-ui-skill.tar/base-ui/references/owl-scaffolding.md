# Nodex JS scaffolding: end-to-end workflow

Covers everything from a brand-new static project to a fully tested, dual-API (pure Nodex UI + static-adapter) component, using the scripts in `scripts/`. This is the reference to read when a task is "create a Nodex component/project" rather than "edit an existing page/plugin" — it covers the component-library shape (like `base-ui`), not a GrapesJS page-builder.

## The three scripts

| Script | Does | Typical flags |
| --- | --- | --- |
| `new-owl-project.mjs` | Scaffolds a whole project: `package.json`, Nodex facade, build, dev server, Vitest config, browser example | `--name --namespace --facade --owl-version` |
| `new-owl-component.mjs` | Scaffolds one component's 4-5 file contract | `--dir --namespace --facade --registry-global --registry-import --behavior --register` |
| `new-owl-test.mjs` | Scaffolds a Vitest mount test for one component | `--dir --test-dir --namespace --facade` |

All three are plain Node, no dependencies, and safe by default (skip existing files unless `--force`).

## Workflow 1: brand-new project

Use when the repo is empty/greenfield and the task describes a Nodex component library, design system, or static/CDN-installable widget set (not a GrapesJS page builder).

```bash
node scripts/new-owl-project.mjs <target-dir> --name <pkg-name> --namespace <ns>
cd <target-dir> && npm install && npm run build && npm run test && npm run dev
```

This gives you a working skeleton with one passing smoke test (`test/owl-facade.test.js`) before you've written a single real component — confirm it builds and tests green first, then start adding components.

## Workflow 2: add a component to an existing project

```bash
node scripts/new-owl-component.mjs <slug> --dir src/components --namespace <ns> --register
node scripts/new-owl-test.mjs <slug> --dir src/components --namespace <ns>
```

`--register` auto-appends the export to `<dir>/index.js` — skip it only if the target project's aggregator has a different shape (grouped exports, barrel per category, etc.) and wire the export by hand instead.

What the scripts do **not** do for you — always finish these manually:

1. **Real props/markup.** The generated `.component.js`/`.xml` are a working skeleton (default slot, `className` prop) — replace with the component's actual props, variants, and template structure.
2. **Registry wiring for the static adapter.** The generated `<slug>.js` assumes a `Registry.register(slug, { type, mount })`-shaped API (defaults tuned to `base-ui`'s `NodexUI.register(...)`). If the target project's static/CDN registry looks different, fix the import and call shape — the file has a `TODO` marking exactly where.
3. **Build wiring**, if the project has one beyond what `new-owl-project.mjs` generated: add the component to any XML-concatenation step, registry metadata file, or docs generator the project already has (e.g. `base-ui`'s `src/registry/nodexui.registry.json` `buildFiles`).
4. **Docs**: props table, events/callback-props table, accessibility notes, and a static-vs-component usage example — see `docs/component-authoring.md` in `base-ui` for the exact structure to mirror in other projects.

## Workflow 3: converting an existing static-only component to dual API

Some components in an older/partially-migrated project only have `<slug>.js` (static adapter) with no `.component.js`/`.xml`. To add the pure Nodex UI side without disturbing the working static behavior:

1. Run `new-owl-component.mjs <slug> --dir <dir> --namespace <ns>` **without** `--force` — it writes only the missing `.component.js`/`.xml` (and `.css` if that's also missing) and leaves the existing `.js` untouched.
2. Extract any DOM/state logic the static adapter duplicates into a `<slug>.behavior.js` (rerun with `--behavior`, or hand-write it) so both APIs consume the same source of truth instead of drifting.
3. Add the component-side test with `new-owl-test.mjs`; keep the existing static test as-is.

## Gotchas worth knowing before you scaffold

- **Cross-bundle Nodex identity.** If the project ships its own Nodex facade bundle (like `base-ui`'s `dist/base-owl.esm.js`) *and* a components bundle that reads `Component` off `globalThis.owl`, both must resolve to the *same* Nodex instance, or mounting throws `"X" is not a Component. It must inherit from the Component class` even though both sides are nominally the same Nodex version. If the build uses an `owlGlobalPlugin`-style shim for one browser bundle, apply it to every bundle meant to interoperate with it.
- **Templates are not auto-available.** A component's `.xml` is only a real Nodex template once something concatenates it into a templates bundle (or a test loads it directly, as `new-owl-test.mjs`'s output does) — don't assume `<Component/>` works in a consumer app without an explicit template-loading step.
- **Static attributes vs Nodex props.** Static/CDN markup uses kebab-case `b-att-*` attributes (or whatever the project's convention is); pure Nodex UI components take camelCase props. Keep both documented side by side rather than assuming one implies the other.
- **Events**: static adapters typically dispatch DOM `CustomEvent`s (`component:*`); pure Nodex UI components should use callback props (`onChange`, `onOpenChange`) instead, not `CustomEvent`s — that's the whole point of the dual-API split.

## When the target project's conventions differ from the defaults

The scripts default to `base-ui`'s conventions (`--namespace nodexui`, `--registry-global NodexUI`, `--facade nodexui`) because that's the reference implementation this pattern was drawn from. For any other project: check its `package.json` name, an existing component if one exists, and any project brief or repo docs before picking flag values — don't assume the defaults apply.
