# Create an Electron/desktop app (`create electron app` / `create window app`)

Reference: https://www.electronjs.org/docs/latest/tutorial/tutorial-first-app

An Electron app here is: the exact same NodexUI PWA scaffold from `references/scaffold-pwa.md`,
loaded as a local file by an Electron `BrowserWindow` instead of served over HTTP, plus the two
Electron-only process files. Scaffold the PWA first, then add the Electron shell around it —
don't build the app twice.

## File layout (added on top of the PWA scaffold)

```
<app>/
  ... (everything from scaffold-pwa.md, unchanged)
  package.json          # Electron entry, scripts, electron-builder config
  main.js                # Electron main process: creates the BrowserWindow, app lifecycle
  preload.js              # contextBridge: the only place that touches Node APIs
```

## package.json

```json
{
  "name": "<app>",
  "version": "1.0.0",
  "main": "main.js",
  "scripts": {
    "start": "electron ."
  },
  "devDependencies": {
    "electron": "^latest-pinned-version"
  }
}
```

Pin the actual Electron version present in the project/lockfile — don't hardcode `latest` in a real
package.json, only in throwaway exploration.

## main.js

```js
const { app, BrowserWindow } = require("electron");
const path = require("node:path");

/** Opens the app's single window, loading the same index.html the PWA build already produces. */
function createWindow() {
  const win = new BrowserWindow({
    width: 1024,
    height: 768,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.loadFile("index.html");
}

app.whenReady().then(() => {
  createWindow();
  // macOS convention: keep the app running and re-open a window when the dock icon is clicked.
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

// Every other platform quits the app when all windows are closed.
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
```

`contextIsolation: true` + `nodeIntegration: false` is required — the renderer (the NodexUI Nodex app)
must never get direct `require()` access. Anything the UI needs from Node/OS (file system, native
dialogs, etc.) goes through `preload.js`.

## preload.js

```js
const { contextBridge } = require("electron");

/** Exposes only the specific, narrow APIs the renderer needs — never the whole Node/Electron surface. */
contextBridge.exposeInMainWorld("desktop", {
  // e.g. version: () => process.versions.electron,
});
```

Leave this empty (as above) until the app actually needs a Node/OS capability the browser sandbox
can't provide (native file dialogs, OS notifications beyond the Web Notifications API, etc.) — don't
pre-expose speculative APIs.

## What changes vs. the plain PWA scaffold

- `win.loadFile("index.html")` loads the same `index.html` from `scaffold-pwa.md` unmodified — no
  separate Electron-flavored HTML.
- The service worker (`sw.js`) and manifest are harmless but redundant inside Electron (there's no
  installability prompt to serve); keep them only if the app is meant to also run as a normal web
  PWA from the same source, drop them if this is Electron-only.
- CDN-hosted NodexUI assets still work inside Electron (it has full network access by default), but
  for a fully offline-capable desktop app, vendor `dist/nodexui.min.css`/`nodexui.esm.js`/
  `nodexui.templates.xml` locally and point the importmap at relative paths instead of jsDelivr.

## Verify

Run `npx electron .` (or the project's `npm start`) from `<app>/` and confirm the window opens with
no DevTools console errors. Close the app process before ending the task.
