# Build a website with NodexUI (`create website`, `build a website`)

A website is not a small app. Visitors arrive from search or a shared link, on any page, often on a
phone. This playbook orders the decisions so each page gets the right layout, only real components,
and the SEO and speed basics. Work the steps in order; each names the reference to open instead of
repeating it here.

## Table of contents

- Website mode or app mode
- Components: pure Nodex UI by default
- The page shape (one HTML file per page, one Nodex root per page)
- Step 0–10 (the playbook)
- Definition of done

## Website mode or app mode

| The user wants… | Mode | Start from |
| --- | --- | --- |
| Pages people read or find via search: landing, marketing, docs, portfolio, blog, brochure | **Website** (this file) | multi-page, no build step |
| Something people operate: forms with state, dashboards, realtime, offline data, one persistent shell | **App** | `scaffold-pwa.md` (`create app`) |
| Website that needs login/dashboard pages or lots of pages/content | **Website, Vite path** | `npx -p nodexui create-nodexui-app init <name>` (landing, login, signup, home shell), then continue at step 2 |

## Components: pure Nodex UI by default

Build every page from pure Nodex UI components (`<Button/>`, `<Card/>`, `<Tabs/>` in Nodex templates, imported
from `nodexui`). Do **not** reach for static `b-ui="…"` / `b-att-*` markup because the site
"is static": a no-build site still loads Nodex and NodexUI through an import map, so pure Nodex UI works on
any static host. Pure Nodex UI gives props, slots, event callbacks and one consistent API across pages,
and it is what blocks and the landing example are written in.

Use static `b-ui` markup only when the user asks for it or the target cannot run Nodex: they say "plain
HTML", "no JavaScript", "no build/no framework", or the page is CMS-managed, server-rendered or
inside a Base HUB website page. Say in the report that you chose it and why. Never mix the two APIs
on one page.

## The page shape

Why this shape: each page keeps its own URL, `<title>`, description and share tags in the static
`<head>` (what crawlers and link previews read), while the body is rendered by Nodex components that
the pages share.

```
<site>/
  index.html, work.html, about.html, …   # one per page: static head + <div id="app" data-page="work">
  site.js                                 # shared: page registry, SiteHeader/SiteFooter, mountPage()
  site.xml                                # shared + per-page Nodex templates (site.* / page.*)
  site.css  favicon.svg  robots.txt  sitemap.xml
```

- Each page's `<head>`: import map **first** (see `scaffold-pwa.md` → `index.html` for the exact head,
  preload lines and version pin), then `modulepreload` for `site.js`, the stylesheet links, then
  `<script type="module" src="/site.js">`. Body: `<div id="app" data-page="work"></div>` plus a
  `<noscript>` block with the page's heading, one summary paragraph and the nav links, so crawlers
  and JS-off visitors still get real text.
- `site.js` imports components from `nodexui`, defines `SiteHeader`/`SiteFooter` and one
  `Root` class per page (each `static template = "page.work"`, with the shared header/footer in its
  template), keeps them in a `pages` map keyed by `data-page`, and mounts the one that matches. Merge
  templates exactly as `scaffold-pwa.md` → `<app>.js` shows (fetch `nodexui/templates` and `site.xml`,
  `stripTemplatesWrapper` with the `[^>]*` regex, one `<templates>` root, then `mount`). Once the
  site passes about six pages or `site.xml` gets large, split per-page templates into
  `pages/<page>.xml` and fetch only the current page's file.
- Nav links are plain `<a href="work.html">` in the shared header, so navigation is real page loads
  with real URLs. Mark the current page with `aria-current="page"` using the page key.

## The playbook

### Step 0: Brief (ask only what changes the build)
Purpose and audience, the pages wanted, where content comes from (user-supplied, placeholder, a
file), brand colors/logo, and whether it must be installable/offline. Make a stated assumption for
anything unanswered rather than interviewing at length. Pick a starter from `website-templates.md`
when the site matches one.

### Step 1: Pin the version
Resolve the `nodexui` version once with `SKILL.md` → "Pin the `nodexui` version once" and
reuse it in every file; state it in the report.

### Step 2: Site map and a layout per page
List the pages, then choose **one layout per page** from `page-layouts.md` (hero landing for the home
page, two column for docs, grid or masonry for a gallery, single column for articles…). Write the map
in your reply before coding. If a page matches a sidebar, login, signup, dashboard or data-table
block, plan to start from that block (`online-sources.md`).

### Step 3: Scaffold
Create the folder shown above with the pinned CDN head from `scaffold-pwa.md`, `site.js`, `site.xml`,
`site.css`, `favicon.svg`, `robots.txt`, `sitemap.xml`.

### Step 4: Shared shell
Build `SiteHeader` (brand, nav, `ThemeButton` if wanted) and `SiteFooter` once in `site.xml`, with
landmarks (`header`, `nav`, `main`, `footer`): one `main` and one `h1` per page. Theme with
NodexUI variables (`var(--bs-body-bg)`), never hard-coded colors, so dark mode works.
`/examples/components/landing/landing.xml` (see `online-sources.md`) is a complete pure Nodex UI
header/hero/features/footer reference.

### Step 5: Build the pages, one at a time
For each page: lay out the sections with the chosen layout, then fill them with NodexUI components.
Before using any component or icon follow the lookup chain in `SKILL.md`: `syntax.md` (pure Nodex UI
prop syntax) → `components.md` (resolve props from the registry) → `icons.md`. If the local tiers do
not answer it, fetch the component doc or the matching block per `online-sources.md`. Finish and
open each page before starting the next so a mistake does not repeat across pages. Use real or
clearly marked placeholder copy, an `alt` on every image, and explicit `width`/`height` (or
`AspectRatio`) so layout does not jump.

### Step 6: Behavior
Add only what the content needs: scroll patterns (`scroll-patterns.md`), loading states
(`loading-patterns.md`), the responsive ladder (`responsive-layout.md`, mobile first), a mobile
bottom bar (`bottom-menu.md`) if it is app-like. Respect `prefers-reduced-motion`.

### Step 7: SEO and sharing
Per page, in the static `<head>`: unique `<title>` (about 50–60 characters) and meta `description`
(about 150–160), `<link rel="canonical">`, `og:title`/`og:description`/`og:image`/`og:url`,
`twitter:card`, and `lang` on `<html>`. Site-wide: `favicon.svg`, `robots.txt` (with a `Sitemap:`
line), and `sitemap.xml` listing every page with absolute URLs. Ask for the production domain; use a
clearly marked placeholder (`https://example.com`) if unknown and say so. Because bodies render
client-side, tell the user if a page's search ranking matters a lot and offer pre-rendering as a
follow-up rather than silently promising it.

### Step 8: Performance
Measure before tuning: `scripts/measure-cold-load.mjs`, then apply `load-performance.md` (flat
`modulepreload` list, pinned CDN with `preconnect`, no unused components, sized/lazy images below
the fold); confirm with `scripts/check-preload-graph.mjs`.

### Step 9: Optional PWA
Only if the user wants installable/offline: `scaffold-pwa.md` → `create-nodexui-app pwa` (manifest,
service worker, `version.json` auto-reload). A plain brochure site does not need it; a service
worker you do not need is a cache-invalidation bug waiting to happen.

### Step 10: Verify, then deploy notes
Serve the folder (`python3 -m http.server` or `npx serve`) and load every page at a phone width
(about 375px) and a desktop width: no console errors, every nav link and `sitemap.xml` URL
resolves, every component actually rendered (no blank page: that is usually the template merge),
the h1/title/description are present, and `grep -r 'b-ui=' <site>` finds nothing unless the user
asked for static markup. Check `syntax.md` §8 against what you wrote. Kill any server you started.
Deploy notes: any static host (upload the folder, keep `index.html` at the root, set the real domain
in canonical/OG/sitemap).

## Definition of done

Report: version used, which component API you used (pure Nodex UI unless the user asked otherwise),
site map with the layout per page, files created, which online sources (if any) were consulted with
their raw URLs or paths and whether they matched the pinned version, what you verified at which
widths, and anything left as placeholder. Every function in `site.js` has the one-line plain-language
comment `SKILL.md` requires.
