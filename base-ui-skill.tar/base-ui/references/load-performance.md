# Optimize page load and reload time (Nodex + NodexUI static SPA)

Use when the user says the app is slow to load/reload, asks to lazy-load, preload, cut requests, or improve first paint. These rules come from measured passes on a real no-bundler Nodex + NodexUI SPA (cold `/login` and a signed-in list page). Each one names the symptom it fixes, so apply only what the measurement shows.

## 0. Measure first (and measure honestly)

Guessing is the main way this work goes wrong: one "obvious" fix (restructuring boot awaits) would have saved nothing because the real gate was render-blocking CSS, and a 850 ms main-thread hot spot hid in a DOM translator nobody suspected.

- `node scripts/measure-cold-load.mjs --url <page> --selector <css that means "content visible">` prints FCP, time-to-content, the slowest requests and a CPU profile (top self-time functions). Needs `playwright-core` + a Chromium; `--bw` (KB/s), `--rtt` (ms), `--cpu` (x slowdown) throttle; `--session-storage '{"key":"json"}'` signs in a persisted-session app.
- The service worker serves static files from cache and **hides first-visit cost**. Measure with it blocked (the script does: Playwright `serviceWorkers: "block"`) and with the HTTP cache disabled. Compare before/after under the same throttle, two runs each, and report the numbers.
- Read three things: the request waterfall (serial chains), the CPU profile (what blocks the main thread), and which request gates `main.js` starting.

## 1. `index.html` head rules

- **Import map first.** It must precede every `modulepreload` link and module script. A module fetch started earlier makes the browser ignore the map and the app never paints (unresolved `nodexui`).
- **Render-blocking CSS delays module execution.** Module scripts do not run until blocking stylesheets are loaded, so a slow CDN stylesheet pushes `main.js` back by its full download time. Keep blocking CSS to what first paint needs; load the other theme variant as `media="print" onload="this.media='all'"` (and make it blocking again from an inline script when the stored theme needs it).
- `preconnect` to the CDN origin; link the font stylesheet that a CSS `@import` would otherwise discover late.
- Set the theme attribute (`b-theme` / `data-bs-theme`) from storage in a tiny inline script before any stylesheet paints, to avoid a light-to-dark flash.
- Start fetches the boot code will need (a module manifest, the NodexUI templates XML) in an inline script or `<link rel="preload" as="fetch" crossorigin>` so they overlap the module graph download.
- Pinned CDN URLs in preload lines must equal the import map and `main.js`, and are part of any version bump.

## 2. Flatten the module graph (preload lists)

`modulepreload` only discovers imports one level at a time after each file is parsed, and each Nodex component's template XML (loaded with a top-level `await loadTemplate(new URL("./X.xml", import.meta.url))`) is only requested after its JS evaluates. On a cold visit that is a staircase of round trips.

- List the **whole static closure** (JS plus template XML) in `index.html`: `modulepreload` for JS, `preload as="fetch" crossorigin` for XML. Duplicates are harmless.
- Make the list conditional when the app has signed-out pages: an inline script reads the persisted session and injects the links only for signed-in visits on app routes, so the login page never downloads the app shell. Split the lists per route family (shell / page / default view) so a route pays only for what it mounts.
- Lists rot silently, and a stale list only loses the speed-up. Verify with `node scripts/check-preload-graph.mjs --root <app dir> --html index.html --entry <module> [--entry ...] [--alias @/=./]` after adding or removing a static import or a template XML. It fails on any closure file missing from `index.html`.

## 3. Lazy-load what most visits never use

Never statically import a heavy or rarely used component into code that every route loads. Seams that worked:

- **Registry with loaders.** `{ componentName, loadComponent: () => import("./X.js").then((m) => m.X), ... }` plus a cached `resolve(name)`. Before first render, `await` the one needed class and assign it to the host's `static components` (Nodex resolves `constructor.components[name]` at render time, so late registration is fine). A page then downloads only the view type it shows.
- **Rare dialogs/editors.** Bundle them behind one dynamic import, load it when the page is idle (`requestIdleCallback` with a timeout, `setTimeout` fallback), and render them under a `dialogsReady` flag. If the user clicks first, the dialog appears when the load finishes.
- **Per-feature helpers.** Utility modules used by one view type load with that view (`Promise.all([fetchData(), importUtils()])`) instead of being imported by the shared page.
- **Heavy third-party scripts** (markdown, rich-text, PouchDB, charts, maps): one loader module that injects the script/CSS once and returns a promise; callers `await` it before touching the global.
- **Route CSS** is injected by the component that needs it, not a `<link>` in `index.html`.
- Do not lazy-load things that are on every first paint (shell, sidebar, control panel); that only adds a round trip.

## 4. Runtime-specific traps that multiply work

- **Never write a parent's state before it is mounted while a child is still in `onWillStart`.** The parent re-renders, Nodex rebuilds the child component, and every request the child's `onWillStart` made is repeated (seen as 3x identical RPCs). Start the request early in `setup()` but write the result only after mount (`await this.whenMounted`), or use `onMounted`.
- Don't block a parent's first render on nice-to-have requests (menus, translations): paint from a cached copy (localStorage) or a loading state and refresh in the background.
- A `get_terms`-style pre-fetch that only a narrow layout needs (phone cards) must be gated by that layout (`matchMedia`), or it blocks every desktop render.

## 5. Cut round trips before first data

- Resolve all per-type lookups in **one** query (`type in [...]`, first row per type wins) and remember the ids so the next metadata fetch skips them.
- Share one metadata call per model within a few seconds (in-flight promise + short TTL, drop it on failure) instead of two callers each paying a round trip.
- Start independent fetches together: records fetch beside the arch/metadata fetch, the dashboard waits on the arch only.
- Read the exported API helpers before adding a request; duplicate lookups come from components inlining their own.

## 6. Main-thread hot paths

Profile before editing; in the measured app the fixes below turned about 850 ms of JS into about 80 ms.

- A `MutationObserver` that decorates every added node (translators, tooltips, linkifiers) must: return early when nothing applies (e.g. source language), memoize derived state keyed on the state object identity (language code, normalized locale), walk **text nodes only** (`createTreeWalker(root, SHOW_TEXT)`) and find attribute targets with one `querySelectorAll("[placeholder],[title],[aria-label]")`, and check "inside a skipped area" once per added subtree (`root.closest(...)` + `root.querySelector(...)`), not with an ancestor loop per node.
- Cache `Intl.DateTimeFormat` per time zone; parse persisted settings once, keyed by the raw string, not per table cell.
- Avoid per-cell `JSON.parse(sessionStorage...)`, regex construction, or `new Intl.*` inside render loops.

## 7. Service worker and caching

- The Cache API keys by URL and ignores `Authorization`: never cache authenticated endpoints; keep API prefixes in the bypass list (and add new ones when the backend gains a top-level prefix).
- Purge the cache only when `version.json` changes, and fetch `version.json` network-first. Stamp it on every deploy, or users keep stale code.
- Cold-load numbers must be taken with the worker blocked (section 0), or regressions hide behind the cache.

## 8. Don't

- Don't restructure boot `await`s (manifest, templates) for speed without a timing mark showing they are the gate. Add temporary `performance.mark` calls, read them, then remove them.
- Don't add a bundler to fix request counts: flat preload lists plus HTTP/2 do the same without breaking the no-build contract.
- Don't preload everything for everyone: signed-out and rarely visited routes must not pay for the app shell.

## Checklist before reporting done

- [ ] Before/after numbers from the same throttle, service worker blocked (FCP and time-to-content).
- [ ] Import map still precedes every preload; `node scripts/check-preload-graph.mjs ...` passes.
- [ ] Signed-out page downloads none of the app-shell files (check the Network tab).
- [ ] Every route/view you touched still mounts with a clean console; lazy dialogs still open.
- [ ] No parent state written before mount while a child loads (no duplicated requests in the waterfall).
