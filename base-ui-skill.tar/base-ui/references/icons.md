# Use/make an icon (`use <icon>` / `make <icon>`)

## Step 1 — resolve the exact icon name from the shipped manifest

Every `nodexui` install ships an icon manifest at `dist/icons/lucide.json`, regardless of npm vs.
CDN. Find it at, in order of likelihood:

1. In the NodexUI source repo: `dist/icons/lucide.json` after `npm run build` (`dist/` is gitignored)
2. `node_modules/nodexui/dist/icons/lucide.json` (npm install)
3. The pinned CDN URL, e.g. `https://cdn.jsdelivr.net/npm/nodexui@<version>/dist/icons/lucide.json`
   — use the version resolved by `SKILL.md`'s "Pin the `nodexui` version once"
   section, not a guess.

It looks like this:

```json
{
  "name": "lucide",
  "version": "1.31.0",
  "count": 2025,
  "cdnBaseUrl": "https://cdn.jsdelivr.net/npm/lucide-static@1.31.0/icons",
  "selfHostedPath": "icons/lucide",
  "icons": ["a-arrow-down", "a-arrow-up", "accessibility", "activity", "alarm-clock-check", "alert-circle", "alert-octagon", "alert-triangle", "..."]
}
```

Match the user's requested icon name against the `icons` array (kebab-case) — this is the full,
exact, versioned list of every icon NodexUI can actually render, so treat it as ground truth rather
than recalling Lucide names from memory. Don't guess a close-sounding name: `alert-circle`,
`alert-triangle`, and `alert-octagon` are all real, distinct icons, and only this list tells you
which ones actually exist in the version this project has pinned. If nothing matches closely, say so
rather than emitting a name that isn't in the manifest.

If the project self-hosts icons instead of using the CDN (check `manifest`'s `selfHostedPath`, or an
explicit `b-icon-base-url`/`cdnBaseUrl` override in the project's code), the actual SVG files live
at that path (npm: `node_modules/nodexui/dist/icons/lucide/<name>.svg`) — you can open one
directly to double check it exists and see its raw markup if needed.

NodexUI normalizes kebab-case, camelCase, snake_case, and space-separated forms to the same icon, but
always author markup in kebab-case to match the manifest and avoid relying on that normalization.

## Step 2 — pick the API

**Static markup** (`b-icon` attribute) — the default for any static HTML context, and also valid
inside a Nodex app's template as plain markup when the icon doesn't need a named Nodex export:

```html
<button b-ui="button" type="button">
  <span b-icon="search"></span>
  Search
</button>

<span b-icon="bell" b-icon-size="20px"></span>
```

**Pure Nodex UI `Icon` component or named icon export** — when the surrounding code already imports
NodexUI components and wants the icon as a first-class Nodex prop/child rather than raw markup:

```js
import { Icon } from "nodexui";
// or, if this app's build imports individual named icons (importmap key "nodexui/icons" for CDN apps):
import { IconSearch } from "nodexui/icons";
```

The registry's `icons.lucide` entry (`dist/nodexui.registry.json`, same file as `components.md` Step 1)
records the current naming convention for named exports — `namedOwlComponents.pattern`, e.g.
`Icon<PascalCaseName>` with `example: "IconEye"` — and which entry file they come from
(`namedOwlComponents.entry`, e.g. `nodexui.icons.esm.js`). Check that instead of assuming the pattern
hasn't changed. Use whichever style (generic `<Icon name="..."/>` vs. named export) this app already
imports elsewhere — don't mix both for the same icon across one codebase.

## Step 3 — color and size

Icons inherit `currentColor` by default — set color via the surrounding button/link/theme, not a
hardcoded fill. Only set `b-icon-size` (static) or the component's size prop when the surrounding
component's own sizing genuinely doesn't fit (e.g. a bare icon with no button/badge wrapper).

## Step 4 — verify

Confirm the exact icon name exists in the manifest you actually read in Step 1 (`dist/icons/lucide.json`'s
`icons` array) before treating the task as done — not from memory, and not from a name that merely
sounds plausible.

See also `docs/icons.md` (sizing, accessibility, self-hosting) and, for CDN apps, pin the icon source
with `window.thebase.icons.lucide.cdnBaseUrl` as `qr-page/qr-page.js` does.
