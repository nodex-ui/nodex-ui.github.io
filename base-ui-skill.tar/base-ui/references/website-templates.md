# Starter website recipes

Each recipe is a page list with one layout per page (names from `page-layouts.md`) and the NodexUI
parts to reach for. They are starting shapes, not fixed templates: trim pages the user did not ask
for, and verify every component against `syntax.md` / the registry as usual. Follow the
`build-website.md` steps for everything else.

## Table of contents

- Landing site
- Docs site
- Portfolio
- Blog
- Site with login and dashboard

## Landing site (product, shop, event, service)

| Page | Layout | Parts |
| --- | --- | --- |
| `index.html` | Hero Landing, with a Z-Pattern CTA flow | hero (`display-4`, one primary `Button`), 3-up `Card` features, `Accordion` FAQ, signup `Field` + `Input` + `Button`, footer |
| `contact.html` (optional) | Split Screen | form `Field`s on one half, brand image/`AspectRatio` on the other |

One primary action for the whole page, repeated, never a second competing one. Testimonials may use a
`Carousel`, never the hero. Reference markup: `landing.xml` in `online-sources.md`.

## Docs site (product docs, handbook, knowledge base)

| Page | Layout | Parts |
| --- | --- | --- |
| `index.html` | Hero Landing (short) | title, search `Command`/`Input`, links into sections |
| `docs/<topic>.html` (one per topic) | Two Column | `Sidebar` (or `row col-lg-3`) nav in `ScrollArea`, content at ~65ch, `Breadcrumb`, `Separator`, previous/next links, `Tabs` for code variants |

Fixed sidebar plus fluid content; on mobile the sidebar becomes a `Sheet`/`Drawer`. Blocks
`sidebar-01`…`sidebar-16` cover many docs shells; check them before building one.

## Portfolio (designer, photographer, agency)

| Page | Layout | Parts |
| --- | --- | --- |
| `index.html` | Asymmetrical or Hero Landing | one dominant featured project, smaller offset tiles, short intro |
| `work.html` | Masonry (mixed heights) or Grid (uniform) | image `Card`s, `Badge` tags, `Skeleton` while images load |
| `work/<project>.html` | Single Column | lead image, case-study text, `Separator`s, next-project link |
| `about.html`, `contact.html` | Split Screen | portrait + bio, contact `Field`s |

Images dominate: give every one explicit dimensions and `loading="lazy"` below the fold.

## Blog

| Page | Layout | Parts |
| --- | --- | --- |
| `index.html` | Magazine (lead story + secondary + small) or Grid | `Card`s with date `Badge`, `Pagination` |
| `posts/<slug>.html` | Single Column | title, byline, ~65ch body, `AspectRatio` hero image, share links, related posts |
| `about.html` | Single Column | short bio |

Each post needs its own title/description/OG tags and an entry in `sitemap.xml`; add a `feed.xml`
(RSS) when the user wants subscribers.

## Site with login and dashboard

Use the Vite path: `npx -p nodexui create-nodexui-app init <name>` scaffolds landing, login, signup and an
authenticated home shell (ported from the `login-03`/`signup-03`/`sidebar-02` blocks). Then adapt
pages per `build-website.md` step 5. If the site is mostly the signed-in product, treat it as an app
(`scaffold-pwa.md`) instead.
