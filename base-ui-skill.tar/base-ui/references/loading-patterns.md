# Loading patterns (`add <pattern> loading`)

Users name a loading behavior ("skeleton", "spinner", "optimistic UI", "pull to refresh"). Pick the
recipe below, build it from the NodexUI parts that exist (`Spinner`, `Skeleton`, `Progress`,
`Button`), and add only small CSS for what NodexUI lacks (progress ring, blur-up, pull indicator).
For app-shell/cold-start speed (not a visual loader) use `references/load-performance.md` instead.

## Table of contents

- Picking a pattern
- The 12 patterns
- Cross-cutting rules

## Picking a pattern

| Situation | Pattern |
| --- | --- |
| Short unknown wait, nothing to show yet | Spinner |
| Page/list/card content is coming, layout is known | Skeleton screen |
| Known progress (upload, download) | Progress bar |
| Images below the fold | Lazy loading |
| Known progress, compact or in a card | Progress ring |
| Large hero/photo images | Blur-up image |
| Multi-step flow (upload → process → done) | Stepper progress |
| Long lists/feeds | Infinite scroll (see `references/scroll-patterns.md` §4) |
| AI/chat answers | Streaming text |
| Likes, toggles, quick edits | Optimistic UI |
| Mobile lists that can refresh | Pull to refresh |
| Form submit / save action | Loading button |

Rule of thumb: skeleton when the shape is known, spinner when it is not, progress when the amount
is known. Never show both a skeleton and a spinner for the same region.

## The 12 patterns

### 1. Spinner
`<Spinner/>` (see `docs/components/spinner.md`). Inline for a region (`className="'m-auto'"`),
centered in a fixed-height wrapper to avoid layout jump. Delay showing it ~200ms
(`setTimeout` set in `onMounted`, cleared in `onWillUnmount`) so fast responses never flash it.

### 2. Skeleton screen
Render `Skeleton` blocks matching the real content's size and count (avatar circle via
`shape`, text lines with varied widths, image block with the final aspect ratio). Swap to real
content in one render from `state.loading`; fixed sizes prevent layout shift. Use for lists,
cards, profiles, tables.

### 3. Progress bar
`<Progress value="state.percent" max="100"/>` (registry attrs: `value`, `max`). Pair it with a
filename and a `100%` label; on completion show a check icon. Use `XMLHttpRequest.upload.onprogress`
or a streamed `fetch` reader for the number; with no real number use indeterminate styling, not a
fake percent.

### 4. Lazy loading
Images: `<img loading="lazy" decoding="async" width height>`, always with width/height or
`AspectRatio` so space is reserved. Components/modules: dynamic `import()` on first use (but not
for things on first paint, per `load-performance.md`). Use an `IntersectionObserver` only for
non-image content, with `rootMargin: "200px"`.

### 5. Progress ring
No NodexUI component; use an SVG circle: `r=36`, `stroke-dasharray = 2πr`, `stroke-dashoffset =
2πr × (1 − percent/100)`, `transform: rotate(-90deg)`, transition on `stroke-dashoffset`. Center the
percent text with `font-variant-numeric: tabular-nums`; add `role="progressbar"` and
`aria-valuenow`. Use `stroke="currentColor"` so themes keep working.

### 6. Blur-up image
Ship a tiny (~20px wide) blurred placeholder inline (data URI) in the same box, layered under the
full image. The full `<img>` starts `opacity: 0`, fades in on `load`; the placeholder has
`filter: blur(12px); transform: scale(1.1)` and is clipped by `overflow: hidden`. Check
`img.complete` in `onMounted` because cached images fire `load` before listeners attach.

### 7. Stepper progress
Ordered steps with state per step (`done` / `active` / `todo`) rendered from one `state.step`
index: circle with number or check icon, connector line filled for completed steps. Use `ol` markup
with `aria-current="step"` on the active one. Steps advance from real events (upload finished,
server confirmed), never from timers.

### 8. Infinite scroll
Sentinel + `IntersectionObserver` + `Skeleton` rows at the end; full recipe in
`references/scroll-patterns.md` §4. Show an explicit "No more results" end state.

### 9. Streaming text
Append tokens to `state.text` as they arrive (`fetch` + `response.body.getReader()` +
`TextDecoder({ stream: true })`, or SSE/WebSocket). Show a `Skeleton` or typing indicator only until
the first token. Batch appends with `requestAnimationFrame` so a fast stream does not trigger a
render per token, keep a blinking caret while streaming, auto-scroll only if the user is already
at the bottom, and let the user stop (`AbortController`). Render markdown at the end, or
incrementally with the `Markdown` component.

### 10. Optimistic UI
Update state immediately, send the request, then reconcile: on success keep it (replace temp id
with the server id), on failure roll back to the saved previous value and show a `Toast`. Keep the
previous value in a local variable of the handler, ignore out-of-order responses (compare a request
counter), and disable repeat taps only if the action is not idempotent. Suited to likes, toggles,
reorder, small edits; not to payments or destructive actions, where wait for confirmation.

### 11. Pull to refresh
Touch only: track `touchstart`/`touchmove` when the scroller is at `scrollTop === 0`, translate an
indicator by the pull distance (with resistance, e.g. `distance × 0.5`), trigger `refresh()` past
~70px, show `Spinner` while loading, then animate back. Use `{ passive: true }` for `touchstart`
and `overscroll-behavior-y: contain` on the scroller to suppress the browser's own refresh. In a
PWA/Capacitor shell this replaces the missing browser gesture; always keep a visible refresh button
for desktop and accessibility.

### 12. Loading button
`<Button disabled="state.saving"><Spinner/>Saving</Button>` swapping the label by state:
`Save` → `Saving…` (spinner, disabled) → `Saved` (check icon, ~1.5s) → `Save`. Disable on first
click so double submits are impossible (this is the cheapest idempotency guard; the server still
needs one for money movement). Keep the width stable by giving the button a `min-width`. Show
failure with `Toast` and re-enable.

## Cross-cutting rules

- **Reserve space**: every loader occupies the final content's footprint, so nothing shifts when
  content arrives (CLS).
- **Delay and minimum time**: show indicators only after ~200ms and, once shown, keep them ≥400ms
  to avoid flicker.
- **Accessibility**: `aria-busy="true"` on the loading region, `role="status"`/`aria-live="polite"`
  for text updates, `role="progressbar"` with `aria-valuenow` for rings. Skeleton shapes are
  decorative (`aria-hidden`).
- **Reduced motion**: shimmer/spin animations stay but slow or become a static pulse under
  `prefers-reduced-motion: reduce`.
- **Errors are part of loading**: every pattern needs a failed state with a retry action, not an
  endless spinner.
- **Cleanup**: abort in-flight requests and clear timers/observers in `onWillUnmount`.
