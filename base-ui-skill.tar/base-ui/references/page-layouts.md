# Website page layouts (`make a <layout> page`, `website layout`, `webpage layout`)

Users name a page by its layout ("holy grail", "split screen", "masonry", "hero landing"). Treat the
name as a vocabulary term: pick the recipe below, build it from NodexUI components for the parts and
built-in utilities for the geometry, and never invent a new layout component. Verify every
component/prop against `references/syntax.md` and the registry as usual.

## Table of contents

- Picking a layout
- The 12 layouts (recipe per layout)
- Cross-cutting rules

## Picking a layout

| Content / goal | Layout | Also described as (second source) |
| --- | --- | --- |
| Long reads, blogs, anything mobile-first | Single Column | simple vertical content flow |
| Docs, dashboards, admin, blogs | Two Column | sidebar + main |
| Product lists, galleries, portfolios | Grid | card-based structure, cards reflow |
| Text pages people scan; popular on landing pages | F-Pattern | optimized for reading, F scan path |
| Landing pages with one CTA; marketing pages | Z-Pattern | guides eye movement, Z scan path |
| Image + pitch, A vs B, modern product showcases | Split Screen | equal sections |
| News sites ranking stories by importance | Magazine | content hierarchy |
| Portfolios, bold campaigns | Asymmetrical | creative composition, modern and visually dynamic |
| Apps: nav, content, extras | Holy Grail | header, 3 columns, footer; classic app shell |
| Mixed-height media feeds, Pinterest-style galleries | Masonry | staggered columns |
| Product launches, signups, conversion-focused pages | Hero Landing | banner + features |
| Stories, one idea per screen, immersive storytelling | Full-Screen | scroll-snap sections |

Two sources name these layouts with slightly different use cases (e.g. Grid for "product lists" vs
"portfolios and galleries", F-Pattern for "text pages" vs "landing pages"); both are valid, so
choose by the content: F-Pattern for dense text, Z-Pattern when one CTA must win.

If the user's request fits two rows (e.g. "docs site with a landing page"), use one layout per page
rather than blending them.

## The 12 layouts

Both source pictures ("Types of Web Page Layouts" and "Types of Webpage Layouts") list the same
12 layouts, so this file is the single reference for them. Class names are base; components are NodexUI. Examples use pure Nodex UI markup; in static HTML
use the `b-ui` equivalents.

### 1. Single Column
One centered column; the content width, not the viewport, sets line length.
`<main class="container py-5" style="max-width: 44rem">` with `Typography`/headings, `AspectRatio`
for the lead image, `Separator` between sections. Same layout on every breakpoint, which is why it
suits mobile.

### 2. Two Column
Fixed navigation column plus a fluid content column. For apps use `Shell` (`ShellSidebar` +
`ShellMain`, collapses to off-canvas on mobile — see `docs/components/shell.md`). For plain docs
pages use `Sidebar` or `row` with `col-lg-3` (nav) / `col-lg-9` (content); put long nav in
`ScrollArea`.

### 3. Grid
Equal cards in rows: `row row-cols-1 row-cols-sm-2 row-cols-lg-3 g-4`, each cell a `Card`
(`CardBody`, title, price `Badge`, `Button`). Keep card heights equal with `h-100`. Use `Pagination`
or `DataTable` for large lists, `Skeleton` while loading.

### 4. F-Pattern
Readers scan a top bar, then a shorter second bar, then down the left edge. Put the strongest
heading and a full-width intro at the top, a second subheading row below it, then left-aligned
content with bold lead words/`Badge`s at line starts. Pure typography/spacing: `Typography`,
`Separator`, left-aligned text; avoid centered body text.

### 5. Z-Pattern
Eye path: logo/nav top-left → CTA top-right → diagonal across hero → CTA bottom-right. Header with
`d-flex justify-content-between` (brand left, `Button` right), hero band (image/`AspectRatio` +
headline), then a final row with a short line left and the primary `Button` right. One primary CTA
only; repeat it, don't add a second.

### 6. Split Screen
Two equal halves, 50/50. `row g-0 min-vh-100` with two `col-lg-6`; one half image/brand panel
(`AspectRatio` or background image), the other the pitch or form (`Field`, `Input`, `Button`) —
the login/signup pattern. For A vs B, two mirrored `Card`s. Stack to one column below `lg`, with
the image half shortened (`min-vh-50`-style fixed `height`), not hidden, unless it is decorative.

### 7. Magazine
One dominant lead story, secondary stories beside it, a row of smaller ones beneath.
`row g-4`: lead `col-lg-8` (large image `Card` with overlay headline), side stack `col-lg-4` of
compact `Item`s/`Card`s, then `row-cols-2 row-cols-lg-4` of small cards. Size signals rank — give
the lead the biggest type and image.

### 8. Asymmetrical
Deliberately uneven composition: one large feature tile plus smaller offset tiles.
Use CSS grid (`display:grid; grid-template-columns: 2fr 1fr; grid-auto-rows`) with the feature
spanning rows (`grid-row: span 2`), or built-in `col-lg-7`/`col-lg-5` with offsets. Keep a single
focal point; asymmetry works only when one element is clearly dominant. Collapse to one column on
mobile in reading order.

### 9. Holy Grail
Header, footer, and a three-column middle: left nav, main content, right extras. Use `Shell` with
`ShellSidebar` (left) + `ShellMain` and place the right rail inside `ShellContent` as a second
column, or `Resizable` panels (`ResizablePanel`/`ResizableHandle`) when the user wants draggable
columns. Main column first in DOM order and `flex: 1 1 0; min-width: 0`; both rails fixed width
(~16rem). Right rail drops below main (or into a `Sheet`/`Drawer`) on small screens.

### 10. Masonry
Cards of mixed heights packed without row gaps. Use CSS columns
(`column-count: 3; column-gap: 1rem`, each item `break-inside: avoid; margin-bottom: 1rem`) — no
JS needed. Responsive: `column-count` 1/2/3 by breakpoint. Note column-flow ordering reads
top-to-bottom per column, so use Grid instead when the order of items matters. Pair with
`AspectRatio`-less images (natural heights) and `Skeleton` placeholders of varied height.

### 11. Hero Landing
Full-width hero (headline, subline, primary `Button`, optional product image) followed by a feature
row of three `Card`s and a closing signup block. Hero: `py-5 text-center` or two-column with the
visual; headline is `display-4`/`display-5`. Signup: `Field` + `Input` + `Button` inline. Add
`Carousel` only for testimonials, never in the hero itself (it hides the CTA).

### 12. Full-Screen (sections)
One idea per viewport: each `<section>` is `min-vh-100 d-flex align-items-center justify-content-center`,
with scroll snap on the container (`scroll-snap-type: y mandatory`; sections
`scroll-snap-align: start`). Centered headline + one supporting line + one action per section. Use
`100dvh` rather than `100vh` on mobile so browser chrome doesn't clip content, and keep tall
content scrollable inside the section.

## Cross-cutting rules

- **Mobile first**: write the single-column version, then add `-sm`/`-lg` classes. Every layout
  above must collapse to a readable single column.
- **Landmarks**: `header`, `nav`, `main` (one per page), `aside` for rails, `footer`; these matter
  for the F/Z/Holy Grail patterns where users orient by position.
- **Content width**: cap body text at ~65–75 characters (`max-width: 44rem` or `65ch`) in any
  layout.
- **Theming**: use NodexUI CSS variables (`var(--bs-body-bg)`, `var(--bs-border-color)`),
  never hard-coded colors, so light/dark keep working.
- **One focal point and one primary action per screen** — most layouts above fail when they have
  two competing ones.
